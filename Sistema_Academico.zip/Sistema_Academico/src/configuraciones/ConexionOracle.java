/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configuraciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Baller
 */
public class ConexionOracle {

    Validaciones configGeneral;

    public Connection _conexion;
    public Statement _sentencia;
    private static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "C##PIS_U";
    private static final String PASWORD = "pisuser";
    //CREATE USER "C##PIS_USER" IDENTIFIED BY "pisuser"  

    public ConexionOracle() {
        this._conexion = null;
        this._sentencia = null;
        this.configGeneral = new Validaciones();
    }

    public Connection conectar() {
        try {
            Class.forName(DRIVER);
            this._conexion = DriverManager.getConnection(URL, USER, PASWORD);

            this._sentencia = this._conexion.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);

        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, configGeneral.conexionBDError + e.getMessage());
            System.exit(0);
        }
        return this._conexion;
    }

    public void desconectar() {
        try {
            this._conexion.close();

        } catch (SQLException e) {
            System.out.println(this.configGeneral.conexionBDError);
            System.exit(0);
        }
    }

    public Statement getSentencia() {
        return _sentencia;
    }
}
