/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configuraciones;

import java.util.regex.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Baller
 */
public class Validaciones extends Config {

    // Definir la expresión regular para la validación del correo electrónico.
    private static final String EMAIL_REGEX = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";

    // Compila la expresión regular en un patrón
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    public boolean validadorDeCedula(String cedula) {
        boolean cedulaCorrecta = false;
        
        try {
            if (cedula.length() == 10) // ConstantesApp.LongitudCedula
            {
                int tercerDigito = Integer.parseInt(cedula.substring(2, 3));
                if (tercerDigito < 6) {
                    // Coeficientes de validación cédula
                    // El decimo digito se lo considera dígito verificador
                    int[] coefValCedula = {2, 1, 2, 1, 2, 1, 2, 1, 2};
                    int verificador = Integer.parseInt(cedula.substring(9, 10));
                    int suma = 0;
                    int digito = 0;
                    for (int i = 0; i < (cedula.length() - 1); i++) {
                        digito = Integer.parseInt(cedula.substring(i, i + 1)) * coefValCedula[i];
                        suma += ((digito % 10) + (digito / 10));
                    }

                    if ((suma % 10 == 0) && (suma % 10 == verificador)) {
                        cedulaCorrecta = true;
                    } else if ((10 - (suma % 10)) == verificador) {
                        cedulaCorrecta = true;
                    } else {
                        cedulaCorrecta = false;
                    }
                } else {
                    cedulaCorrecta = false;
                }
            } else {
                cedulaCorrecta = false;
            }
        } catch (NumberFormatException nfe) {
            cedulaCorrecta = false;
        } catch (Exception err) {
            JOptionPane.showMessageDialog(null, this.msjErrorExepcionCedula, this.msjTituloError, JOptionPane.ERROR_MESSAGE);

            cedulaCorrecta = false;
        }

        if (!cedulaCorrecta) {
            JOptionPane.showMessageDialog(null, this.msjErrorCedulaIncorrecta, this.msjTituloError, JOptionPane.ERROR_MESSAGE);
        }
        return cedulaCorrecta;
    }

    // Validar una dirección de correo electrónico usando el patrón
    public boolean validadorDeEmail(String email) {
        if (email == null) {
            return false;
        }
        // Crea un comparador para la dirección de correo electrónico
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        // Devuelve verdadero si la dirección de correo electrónico coincide con el patrón
        if (!matcher.matches()) {
            JOptionPane.showMessageDialog(null, this.msjErrorEmailIncorrecto, this.msjTituloError, JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public boolean validadorDeClaves(String clave1, String clave2) {
        if (!clave1.equals(clave2)) {
            JOptionPane.showMessageDialog(null, this.msjErrorClavesNoCoinciden, this.msjTituloError, JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

}
