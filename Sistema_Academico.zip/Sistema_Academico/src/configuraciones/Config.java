/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configuraciones;

import controlador.CarreraBD;
import controlador.CursoBD;
import controlador.GeneroBD;
import controlador.MateriaBD;
import controlador.RolBD;
import controlador.UsuarioBD;
import java.awt.event.KeyEvent;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JComboBox;
import javax.swing.text.JTextComponent;
import modelo.Carrera;
import modelo.Curso;
import modelo.Genero;
import modelo.Materia;
import modelo.Rol;
import modelo.Usuario;
import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author Baller
 */
public class Config {

    public String conexionBDCorrecto = "Correcta conexión base de datos.";
    public String conexionBDError = "Error de conexión con base de datos: ";
    public String desconexionBDCorrecto = "Correcta desconexión con la base de datos.";

    public String guardadoCorrecto = "Se guardo exitosanente los datos.";
    public String guardadoError = "Error al guardar los datos: ";

    public String editadoCorrecto = "Se edito exitosanente los datos.";
    public String editadoError = "Error al editar los datos: ";

    public String eliminoCorrecto = "Se elimino exitosanente los datos.";
    public String eliminoError = "Error al eliminar los datos: ";

    public String cargaDatosCorrecto = "Se cargo datos con exito.";
    public String cargaDatosError = "Error al cargar datos: ";

    public String errorCargaTabla = "Error de carga de tabla: ";
    public String errorCargaLista = "Error de carga de lista: ";
    public String errorVerId = "Error de carga por id: ";
    public String errorFechaActualMayorFechaEntraTarea = "Feha actual es mayor a la fecha de entrega de tarea.";
    public String errorInterfaz = "Registre la nueva interfaz";

    /* mensages*/
    public String msjTitulInformativo = "Información";
    public String msjTitulConfirmar = "Confirmar";
    public String msjTituloError = "Error";
    public String msjTituloAdvertencia = "Advertencia";

    public String msjConfirmar = "¿Quieres continuar?";
    public String msjConfirmarGuardar = "¿Quieres guardar?";
    public String msjConfirmarEnviarTarea = "¿Quieres enviar tarea?";
    public String msjConfirmarEliminar = "¿Quieres eliminar?";
    public String msjConfirmarCancelar = "¿Quieres cancelar?";
    public String msjSeleccioneFila = "Porfavor seleccione una fila para continuar.";
    public String msjErrorIngreso = "Usuario ó contraseña erronea";
    public String msjErrorInterfaz = "Problema no exite la interfaz";
    public String msjErrorExepcionCedula = "Una excepcion ocurrio en el proceso de validadción";
    public String msjErrorCedulaIncorrecta = "La Cédula ingresada es Incorrecta. Intente con otra";
    public String msjErrorEmailIncorrecto = "El email ingresado es inválido. Intente con otro";
    public String msjErrorClavesNoCoinciden = "La contraseñas no coinciden. Intente con otra vez";

    public String msjErrorLlenarTodosCampos = "Campos requeridos (*) están vacios, llenelos y vuelva a intentar.";

    //Nombre de tablas
    public String TABLA_ROL = "TB_ROL";
    public String TABLA_GENERO = "TB_GENERO";
    public String TABLA_USUARIO = "TB_USUARIO";
    public String TABLA_CARRERA = "TB_CARRERA";
    public String TABLA_CURSO = "TB_CURSO";
    public String TABLA_MATERIA = "TB_MATERIA";
    public String TABLA_TAREA = "TB_TAREA";
    public String TABLA_TAREA_ENTREGADA = "TB_TAREA_ENTREGADA";
    public String TABLA_MATRICULA = "TB_MATRICULA";

    /*Métodos para encriptar y desencriptar clave*/
    public static String Encriptar(String texto) {
        String secretKey = "qualityinfosolutions"; //llave para encriptar datos
        String base64EncryptedString = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);

            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(Cipher.ENCRYPT_MODE, key);

            byte[] plainTextBytes = texto.getBytes("utf-8");
            byte[] buf = cipher.doFinal(plainTextBytes);
            byte[] base64Bytes = Base64.encodeBase64(buf);
            base64EncryptedString = new String(base64Bytes);

        } catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException ex) {
        }
        return base64EncryptedString;
    }

    public static String Desencriptar(String textoEncriptado) throws Exception {
        String secretKey = "qualityinfosolutions"; //llave para desenciptar datos
        String base64EncryptedString = "";
        try {
            byte[] message = Base64.decodeBase64(textoEncriptado.getBytes("utf-8"));
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");

            Cipher decipher = Cipher.getInstance("DESede");
            decipher.init(Cipher.DECRYPT_MODE, key);

            byte[] plainText = decipher.doFinal(message);

            base64EncryptedString = new String(plainText, "UTF-8");
        } catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException ex) {
        }
        return base64EncryptedString;
    }

    /*Extrae datos de combos*/
    public int getIDComboUsuario(JComboBox combo) {
        int id = 0;
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                Usuario obj = (Usuario) combo.getSelectedItem();
                id = obj.getId();
                return id;
            }
        }
        return id;
    }

    public int getIDComboCarrera(JComboBox combo) {
        int id = 0;
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                Carrera obj = (Carrera) combo.getSelectedItem();
                id = obj.getId();
                return id;
            }
        }
        return id;
    }

    public int getIDComboCurso(JComboBox combo) {
        int id = 0;
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                Curso obj = (Curso) combo.getSelectedItem();
                id = obj.getId();
                return id;
            }
        }
        return id;
    }

    public int getIDComboGenero(JComboBox combo) {
        int id = 0;
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                Genero obj = (Genero) combo.getSelectedItem();
                id = obj.getId();
                return id;
            }
        }
        return id;
    }

    public int getIDComboRol(JComboBox combo) {
        int id = 0;
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                Rol obj = (Rol) combo.getSelectedItem();
                id = obj.getId();
                return id;
            }
        }
        return id;
    }

    public int getIDComboMateria(JComboBox combo) {
        int id = 0;
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                Materia obj = (Materia) combo.getSelectedItem();
                id = obj.getId();
                return id;
            }
        }
        return id;
    }

    public String getNOMBRECombos(JComboBox combo) {
        String nombre = "";
        for (int i = 0; i < combo.getItemCount(); i++) {
            Object element = combo.getModel().getElementAt(i);
            if (element.toString().equalsIgnoreCase(combo.getSelectedItem().toString())) {
                combo.setSelectedIndex(i);
                String obj = (String) combo.getSelectedItem();
                nombre = obj;
                return nombre;
            }
        }
        return nombre;
    }

    /*Cargar combos*/
    public JComboBox getListaComboUsuarioEstudiante(JComboBox combo) {
        try {
            combo.removeAllItems();
            UsuarioBD objBD = new UsuarioBD();
            ArrayList<Usuario> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Usuario obj = (Usuario) iterator.next();
                if (obj.getNombreRol().equals("ESTUDIANTE")) {
                    combo.addItem(obj);
                }
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    public JComboBox getListaComboUsuarioDocente(JComboBox combo) {
        try {
            combo.removeAllItems();
            UsuarioBD objBD = new UsuarioBD();
            ArrayList<Usuario> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Usuario obj = (Usuario) iterator.next();
                if (obj.getNombreRol().equals("DOCENTE")) {
                    combo.addItem(obj);
                }
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    public JComboBox getListaComboCurso(JComboBox combo) {
        try {
            combo.removeAllItems();
            CursoBD objBD = new CursoBD();
            ArrayList<Curso> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Curso obj = (Curso) iterator.next();
                combo.addItem(obj);
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    public JComboBox getListaComboGenero(JComboBox combo) {
        try {
            combo.removeAllItems();
            GeneroBD objBD = new GeneroBD();
            ArrayList<Genero> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Genero obj = (Genero) iterator.next();
                combo.addItem(obj);
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    public JComboBox getListaComboRol(JComboBox combo) {
        try {
            combo.removeAllItems();
            RolBD objBD = new RolBD();
            ArrayList<Rol> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Rol obj = (Rol) iterator.next();
                combo.addItem(obj);
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    public JComboBox getListaComboCarrera(JComboBox combo) {
        try {
            combo.removeAllItems();
            CarreraBD objBD = new CarreraBD();
            ArrayList<Carrera> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Carrera obj = (Carrera) iterator.next();
                combo.addItem(obj);
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    public JComboBox getListaComboMateria(JComboBox combo) {
        try {
            combo.removeAllItems();
            MateriaBD objBD = new MateriaBD();
            ArrayList<Materia> lista = new ArrayList<>();
            lista = objBD.getLista();
            Iterator iterator = lista.iterator();
            while (iterator.hasNext()) {
                Materia obj = (Materia) iterator.next();
                combo.addItem(obj);
            }
        } catch (SQLException ex) {
            System.err.println(this.errorCargaLista + ex.getMessage());
        }
        return combo;
    }

    /* Fecha */
    public String getStringDate(Date fecha) {
        return String.valueOf(new java.sql.Date(fecha.getTime()));
    }

    /*Validar logitud campos*/
    public Boolean getLogitudClave(JTextComponent texto) {
        if (texto.getText().length() == 8) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudTelefono(JTextComponent texto) {
        if (texto.getText().length() == 10) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudCedula(JTextComponent texto) {
        if (texto.getText().length() == 10) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudCelular(JTextComponent texto) {
        if (texto.getText().length() == 10) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudNombre(JTextComponent texto) {
        if (texto.getText().length() == 100) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudNumeroMatricula(JTextComponent texto) {
        if (texto.getText().length() == 100) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudApellido(JTextComponent texto) {
        if (texto.getText().length() == 100) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudDescripcion(JTextComponent texto) {
        if (texto.getText().length() == 500) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudIndicacion(JTextComponent texto) {
        if (texto.getText().length() == 2000) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudFacultad(JTextComponent texto) {
        if (texto.getText().length() == 100) {
            return true;
        }
        return false;
    }

    public Boolean getLogitudNota(JTextComponent texto) {
        if (texto.getText().length() == 5) {
            return true;
        }
        return false;
    }

    /*Validar key campos*/
    public Boolean getkeyNota(JTextComponent texto, int key) {
        if (((key < '0') || (key > '9'))
                && (key != KeyEvent.VK_BACK_SPACE)
                && (key != '.' || texto.getText().contains("."))) {
            return true;
        }
        return false;
    }

    public Boolean getkeyCedula(JTextComponent texto, int key) {
        if (((key < '0') || (key > '9'))) {
            return true;
        }
        return false;
    }

    public Boolean getkeyCelular(JTextComponent texto, int key) {
        if (((key < '0') || (key > '9'))) {
            return true;
        }
        return false;
    }

    public Boolean getkeyTelefono(JTextComponent texto, int key) {
        if (((key < '0') || (key > '9'))) {
            return true;
        }
        return false;
    }
}
