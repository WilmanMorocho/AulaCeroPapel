/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Date;

/**
 *
 * @author Baller
 */
public class Tarea extends DatoBase {

    int idMateria;
    String nombreMateria;

    Date fechaCreacion;
    Date fechaEntrega;
    /*AUX*/
    Double notaTarea;

    public int getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(int idMateria) {
        this.idMateria = idMateria;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    /*AUX*/
    public Double getNotaTarea() {
        return notaTarea;
    }

    public void setNotaTarea(Double notaTarea) {
        this.notaTarea = notaTarea;
    }

    @Override
    public String toString() {
        return getNombre();
    }
}
