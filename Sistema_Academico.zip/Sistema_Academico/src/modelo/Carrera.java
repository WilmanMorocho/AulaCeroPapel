/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Baller
 */
public class Carrera extends DatoBase{
    String facultad;
    int idAsignado;
    String nombreAsignado;

    public String getFacultad() {
        return facultad;
    }

    public void setFacultad(String facultad) {
        this.facultad = facultad;
    }

    public int getIdAsignado() {
        return idAsignado;
    }

    public void setIdAsignado(int idAsignado) {
        this.idAsignado = idAsignado;
    }

    public String getNombreAsignado() {
        return nombreAsignado;
    }

    public void setNombreAsignado(String nombreAsignado) {
        this.nombreAsignado = nombreAsignado;
    }
    
    @Override
    public String toString() {
        return getNombre();
    }
}
