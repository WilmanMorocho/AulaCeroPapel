/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista.perfil;

import configuraciones.Validaciones;
import controlador.MateriaBD;
import controlador.TareaBD;
import controlador.TareaEntregadaBD;
import java.awt.Component;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import modelo.Materia;
import modelo.Rol;
import modelo.Tarea;
import modelo.TareaEntregada;
import modelo.Usuario;
import vista.frmLogin;

/**
 *
 * @author Baller
 */
public class frmDocente extends javax.swing.JFrame {

    /**
     * Creates new form frmEstudiante
     */
    Rol _objRol = new Rol();
    Usuario _objUsuario = new Usuario();
    Materia _objMateria = new Materia();
    Tarea _objTarea = new Tarea();
    TareaEntregada _objTareaEntregada = new TareaEntregada();

    JPanel _jp;
    Component _compenteTablaMaterias;
    Component _compenteTablaTareas;
    Component _compenteTablaTareasEntregadas;
    Component _compenteCalificarTareaEntregada;
    Component _compenteNuevaEdtitarTarea;
    Component _compenteVerTarea;

    String _accion;

    int _ID_Usuario = 0;
    int _ID_Rol = 0;
    int _ID_Materia = 0;
    int _ID_Tarea = 0;
    int _ID_TareaEntregada = 0;
    int _ID_Estudiante = 0;

    Validaciones configGeneral;

    public frmDocente(Rol rol, Usuario usuario) {
        initComponents();
        this.configGeneral = new Validaciones();
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);// desavilita el boton de cerrar en ventana
        this.setResizable(false);//deshabilita botón maximizar
        this.setLocationRelativeTo(null);

        ///Cargamos los datos del Usuario
        this._objRol = rol;
        this._objUsuario = usuario;
        this._ID_Usuario = usuario.getId();

        //Obtenemos los componetes del panel para cada accion de la administración
        this._compenteTablaMaterias = jTPanel.getComponentAt(0);
        this._compenteTablaTareas = jTPanel.getComponentAt(1);
        this._compenteTablaTareasEntregadas = jTPanel.getComponentAt(2);
        this._compenteCalificarTareaEntregada = jTPanel.getComponentAt(3);

        this._compenteNuevaEdtitarTarea = jTPanel.getComponentAt(4);
        this._compenteVerTarea = jTPanel.getComponentAt(5);

        this._accion = "tabla_materias";
        this.tipoTab();
    }

    private void tipoTab() {
        if (this._accion.equals("tabla_materias")) {
            jTPanel.remove(this._compenteTablaMaterias);
            jTPanel.remove(this._compenteTablaTareas);
            jTPanel.remove(this._compenteTablaTareasEntregadas);
            jTPanel.remove(this._compenteCalificarTareaEntregada);

            jTPanel.remove(this._compenteNuevaEdtitarTarea);
            jTPanel.remove(this._compenteVerTarea);

            jTPanel.add(this._compenteTablaMaterias);
            jTPanel.setTitleAt(0, "VER MATERIAS");
            this.cargarTablaMateriasIDDocente(this._objUsuario.getId());
        } else {
            if (this._accion.equals("tabla_tareas")) {
                jTPanel.remove(this._compenteTablaMaterias);
                jTPanel.remove(this._compenteTablaTareas);
                jTPanel.remove(this._compenteTablaTareasEntregadas);
                jTPanel.remove(this._compenteNuevaEdtitarTarea);
                jTPanel.remove(this._compenteVerTarea);

                jTPanel.add(this._compenteTablaTareas);
                jTPanel.setTitleAt(0, "VER TAREAS");
                this.cargarTablaTareasIDMateria(this._objMateria.getId());
            } else {
                if (this._accion.equals("tabla_tareas_entregadas")) {
                    jTPanel.remove(this._compenteTablaMaterias);
                    jTPanel.remove(this._compenteTablaTareas);
                    jTPanel.remove(this._compenteTablaTareasEntregadas);
                    jTPanel.remove(this._compenteCalificarTareaEntregada);

                    jTPanel.add(this._compenteTablaTareasEntregadas);
                    jTPanel.setTitleAt(0, "VER TAREAS ENTREGADAS");
                    this.cargarTablaTareasEntregadasIDTarea(this._objTarea.getId());
                } else {
                    if (this._accion.equals("calificar_tarea_entregada")) {
                        jTPanel.remove(this._compenteTablaMaterias);
                        jTPanel.remove(this._compenteTablaTareas);
                        jTPanel.remove(this._compenteTablaTareasEntregadas);
                        jTPanel.remove(this._compenteCalificarTareaEntregada);
                        jTPanel.add(this._compenteCalificarTareaEntregada);
                        jTPanel.setTitleAt(0, "CALIFICAR TAREA ENTREGADA");
                    } else {
                        if (this._accion.equals("nuevo_tarea")) {
                            jTPanel.remove(this._compenteTablaMaterias);
                            jTPanel.remove(this._compenteTablaTareas);
                            jTPanel.remove(this._compenteTablaTareasEntregadas);
                            jTPanel.remove(this._compenteNuevaEdtitarTarea);
                            jTPanel.remove(this._compenteVerTarea);

                            jTPanel.add(this._compenteNuevaEdtitarTarea);
                            jTPanel.setTitleAt(0, "NUEVA TAREA PARA MATÉRIA DE " + this._objMateria.getNombre());
                        } else {
                            if (this._accion.equals("editar_tarea")) {
                                jTPanel.remove(this._compenteTablaMaterias);
                                jTPanel.remove(this._compenteTablaTareas);
                                jTPanel.remove(this._compenteTablaTareasEntregadas);
                                jTPanel.remove(this._compenteNuevaEdtitarTarea);
                                jTPanel.remove(this._compenteVerTarea);

                                jTPanel.add(this._compenteNuevaEdtitarTarea);
                                jTPanel.setTitleAt(0, "EDITAR TAREA PARA MATÉRIA DE " + this._objMateria.getNombre());
                            } else {
                                if (this._accion.equals("ver_tarea")) {
                                    jTPanel.remove(this._compenteTablaMaterias);
                                    jTPanel.remove(this._compenteTablaTareas);
                                    jTPanel.remove(this._compenteTablaTareasEntregadas);
                                    jTPanel.remove(this._compenteNuevaEdtitarTarea);
                                    jTPanel.remove(this._compenteVerTarea);

                                    jTPanel.add(this._compenteVerTarea);
                                    jTPanel.setTitleAt(0, "VER TAREA PARA MATÉRIA DE " + this._objMateria.getNombre());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /* --------------- CARGAR TABLAS ------------------*/
    private void cargarTablaMateriasIDDocente(int id_docente) {
        try {
            MateriaBD objBD = new MateriaBD();
            jTablaMaterias.setModel(objBD.getTablaMateriaIDDocente(String.valueOf(id_docente)));
        } catch (SQLException ex) {
            System.err.println(this.configGeneral.errorCargaTabla + ex.getMessage());
        } finally {
            jTablaMaterias.getColumnModel().getColumn(0).setMaxWidth(0);//ancho columna de ID
            jTablaMaterias.getColumnModel().getColumn(1).setMaxWidth(40);//ancho columna de N°
            jTablaMaterias.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        }
    }

    private void cargarTablaTareasIDMateria(int id_materia) {
        try {
            TareaBD objBD = new TareaBD();
            jTablaTareas.setModel(objBD.getTablaTareasIDMateria(String.valueOf(id_materia)));
        } catch (SQLException ex) {
            System.err.println(this.configGeneral.errorCargaTabla + ex.getMessage());
        } finally {
            jTablaTareas.getColumnModel().getColumn(0).setMaxWidth(0);//ancho columna de ID
            jTablaTareas.getColumnModel().getColumn(1).setMaxWidth(40);//ancho columna de N°
            jTablaTareas.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        }
    }

    private void cargarTablaTareasEntregadasIDTarea(int id_tarea) {
        try {
            TareaEntregadaBD objBD = new TareaEntregadaBD();
            jTablaTareasEntregadas.setModel(objBD.getTablaTareaEntregaIDTarea(String.valueOf(id_tarea)));
        } catch (SQLException ex) {
            System.err.println(this.configGeneral.errorCargaTabla + ex.getMessage());
        } finally {
            jTablaTareasEntregadas.getColumnModel().getColumn(0).setMaxWidth(0);//ancho columna de ID
            jTablaTareasEntregadas.getColumnModel().getColumn(1).setMaxWidth(40);//ancho columna de N°
            jTablaTareasEntregadas.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        }
    }


    /* --------------- VER DATOS ------------------*/
    private void verMateriaId(String id_materia) throws Exception {
        Materia obj = new Materia();
        try {
            MateriaBD objBD = new MateriaBD();
            obj = objBD.getMateriaID(id_materia);

        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposMateria(obj);
        }
    }

    private void verTareaId(String id_tarea) throws Exception {
        Tarea obj = new Tarea();
        try {
            TareaBD objBD = new TareaBD();
            obj = objBD.getTareaID(id_tarea);
        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposTarea(obj);
        }
    }

    private void verTareaEntregadaId(String id_tarea_entregada) throws Exception {
        TareaEntregada obj = new TareaEntregada();
        try {
            TareaEntregadaBD objBD = new TareaEntregadaBD();
            obj = objBD.getTareaEntregadaID(id_tarea_entregada);

        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposTareaEntregada(obj);
        }
    }


    /* --------------- CARGAR CAMPOS ------------------*/
    private void cargarCamposMateria(Materia obj) throws Exception {
        this._objMateria = obj;
        this._ID_Materia = obj.getId();
        //para nuevo
        lblMateria.setText(obj.getNombre());

    }

    private void cargarCamposTarea(Tarea obj) throws Exception {
        this._objTarea = obj;
        this._ID_Tarea = obj.getId();
        //para tablas
        lblTarea.setText(obj.getNombre());
        lblMateriaEntregada.setText(obj.getNombre());
        txtIndicanionesTarea.setText(obj.getDescripcion());

        //para nuevo
        txtNombre.setText(obj.getNombre());
        jDCreacion.setDate(obj.getFechaCreacion());
        jDEntrega.setDate(obj.getFechaEntrega());
        txtIndicacion.setText(obj.getDescripcion());

        jDCreacion.setMaxSelectableDate(obj.getFechaCreacion());
        jDCreacion.setMinSelectableDate(obj.getFechaCreacion());
        jDEntrega.setMinSelectableDate(obj.getFechaEntrega());

        //para editar
        txtNombre1.setText(obj.getNombre());
        jDCreacion1.setDate(obj.getFechaCreacion());
        jDEntrega1.setDate(obj.getFechaEntrega());
        txtIndicacion1.setText(obj.getDescripcion());
    }

    private void cargarCamposTareaEntregada(TareaEntregada obj) throws Exception {
        this._objTareaEntregada = obj;
        this._ID_TareaEntregada = obj.getId();
        this._ID_Estudiante = obj.getIdEstudiante();
        //para nuevo
        txtDesarrolloTarea.setText(obj.getDescripcion());
        txtNotaTarea.setText(String.valueOf(obj.getNota_entregada()));
        lblEstudiante.setText("Estudiante: " + obj.getNombreEstudiante());
    }

    /* --------------- ADMINISTRAR TAREA ENVIADA ------------------*/
    private void editarTareaEntregada(int ID) {
        TareaEntregada obj = new TareaEntregada();
        TareaEntregadaBD objBD = new TareaEntregadaBD();
        obj.setId(ID);
        obj.setIdEstudiante(this._ID_Estudiante);
        obj.setIdTarea(this._ID_Tarea);
        obj.setNota_entregada(Double.parseDouble(txtNotaTarea.getText()));
        obj.setDescripcion(txtDesarrolloTarea.getText());
        objBD.editar(obj);
    }

    /* --------------- ADMINISTRAR TAREA ------------------*/
    private void guardarTarea() {
        Tarea obj = new Tarea();
        TareaBD objBD = new TareaBD();

        obj.setNombre(txtNombre.getText());
        obj.setFechaCreacion(jDCreacion.getDate());
        obj.setFechaEntrega(jDEntrega.getDate());
        obj.setDescripcion(txtIndicacion.getText());
        obj.setIdMateria(this._ID_Materia);
        obj.setEstado("A");
        objBD.guardar(obj);
    }

    private void editarTarea(int ID) {
        Tarea obj = new Tarea();
        TareaBD objBD = new TareaBD();

        obj.setId(ID);
        obj.setNombre(txtNombre.getText());
        obj.setFechaCreacion(jDCreacion.getDate());
        obj.setFechaEntrega(jDEntrega.getDate());
        obj.setDescripcion(txtIndicacion.getText());
        obj.setIdMateria(this._ID_Materia);
        objBD.editar(obj);
    }

    private void eliminarTarea(int ID) {
        Tarea obj = new Tarea();
        obj.setId(ID);
        TareaBD objBD = new TareaBD();
        obj.setEstado("P");
        objBD.eliminar(obj);
    }

    private void limpiarCamposTarea() {

        //para nuevo
        txtNombre.setText(null);
        jDCreacion.setDate(new Date());
        jDEntrega.setDate(new Date());
        txtIndicacion.setText(null);

        jDCreacion.setMaxSelectableDate(new Date());
        jDCreacion.setMinSelectableDate(new Date());
        jDEntrega.setMinSelectableDate(new Date());

        //para editar
        txtNombre1.setText(null);
        jDCreacion1.setDate(new Date());
        jDEntrega1.setDate(new Date());
        txtIndicacion1.setText(null);
    }

    private Boolean validarCampos() {
        if (txtNombre.getText().trim().isEmpty()) {
            return false;
        }
        if (!jDCreacion.isValid() || jDCreacion.getDate() == null) {
            return false;
        }
        if (!jDEntrega.isValid()|| jDEntrega.getDate() == null) {
            return false;
        }
        if (txtIndicacion.getText().trim().isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTPanel = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnCerrarSesion = new javax.swing.JButton();
        btnActualizarTablaMaterias = new javax.swing.JButton();
        btnVerTareas = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablaMaterias = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        lblMateria = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        btnIrTablaMaterias = new javax.swing.JButton();
        btnVerTareasEntregadas = new javax.swing.JButton();
        btnActualizarTablaTareas = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        btnEliminar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnVer = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTablaTareas = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        lblMateriaEntregada = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        btnCalificarTarea = new javax.swing.JButton();
        btnActualizarTablaTareasEntregadas = new javax.swing.JButton();
        btnIrATablaTareas = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTablaTareasEntregadas = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        lblTarea = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtIndicanionesTarea = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtDesarrolloTarea = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        txtNotaTarea = new javax.swing.JTextField();
        lblEstudiante = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        btnIrTablaTareasEntregadas = new javax.swing.JButton();
        btnActualizarTarea = new javax.swing.JButton();
        btnGuardarTareaEntregada = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtIndicacion = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jDCreacion = new com.toedter.calendar.JDateChooser();
        jDEntrega = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        btnCancelar = new javax.swing.JButton();
        btnGuardarTarea = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        txtIndicacion1 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        txtNombre1 = new javax.swing.JTextField();
        jDCreacion1 = new com.toedter.calendar.JDateChooser();
        jDEntrega1 = new com.toedter.calendar.JDateChooser();
        jLabel18 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnCerrarSesion.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnCerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/cerra_sesion.png"))); // NOI18N
        btnCerrarSesion.setText("Cerrar Sesión");
        btnCerrarSesion.setToolTipText("");
        btnCerrarSesion.setIconTextGap(1);
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });

        btnActualizarTablaMaterias.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTablaMaterias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTablaMaterias.setText("Actualizar");
        btnActualizarTablaMaterias.setActionCommand("btnEditar");
        btnActualizarTablaMaterias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTablaMateriasActionPerformed(evt);
            }
        });

        btnVerTareas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/lista.png"))); // NOI18N
        btnVerTareas.setText("VER TAREAS");
        btnVerTareas.setActionCommand("btnEditar");
        btnVerTareas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerTareasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnCerrarSesion)
                .addGap(334, 334, 334)
                .addComponent(btnActualizarTablaMaterias)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVerTareas)
                .addGap(60, 60, 60))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnActualizarTablaMaterias, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVerTareas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 12, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MIS MATÉRIAS");

        jTablaMaterias = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jTablaMaterias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTablaMaterias.setFocusable(false);
        jTablaMaterias.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane3.setViewportView(jTablaMaterias);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        jTPanel.addTab("tab1", jPanel1);

        lblMateria.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblMateria.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMateria.setText("MATERIA");

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnIrTablaMaterias.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnIrTablaMaterias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnIrTablaMaterias.setText("Ir a Materias");
        btnIrTablaMaterias.setActionCommand("btnEditar");
        btnIrTablaMaterias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrTablaMateriasActionPerformed(evt);
            }
        });

        btnVerTareasEntregadas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnVerTareasEntregadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/lista.png"))); // NOI18N
        btnVerTareasEntregadas.setText("Ver Tareas Entregadas");
        btnVerTareasEntregadas.setActionCommand("btnEditar");
        btnVerTareasEntregadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerTareasEntregadasActionPerformed(evt);
            }
        });

        btnActualizarTablaTareas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTablaTareas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTablaTareas.setText("Actualizar");
        btnActualizarTablaTareas.setActionCommand("btnEditar");
        btnActualizarTablaTareas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTablaTareasActionPerformed(evt);
            }
        });

        jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Administrar Tarea", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/eliminar.png"))); // NOI18N
        btnEliminar.setActionCommand("btnEliminar");
        btnEliminar.setLabel("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnNuevo.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/nuevo.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.setActionCommand("btnNuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/editar.png"))); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.setActionCommand("btnEditar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnVer.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnVer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/ver.png"))); // NOI18N
        btnVer.setText("Ver");
        btnVer.setActionCommand("btnEditar");
        btnVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnNuevo)
                .addGap(18, 18, 18)
                .addComponent(btnEditar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addComponent(btnVer, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnVer, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnNuevo)
                        .addComponent(btnEditar)
                        .addComponent(btnEliminar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnIrTablaMaterias)
                .addGap(33, 33, 33)
                .addComponent(btnActualizarTablaTareas)
                .addGap(18, 18, 18)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69)
                .addComponent(btnVerTareasEntregadas)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIrTablaMaterias, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnActualizarTablaTareas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(16, Short.MAX_VALUE))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(btnVerTareasEntregadas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTablaTareas = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jTablaTareas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTablaTareas.setFocusable(false);
        jTablaTareas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane2.setViewportView(jTablaTareas);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblMateria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1188, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMateria)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 351, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTPanel.addTab("tab2", jPanel2);

        lblMateriaEntregada.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblMateriaEntregada.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMateriaEntregada.setText("MATÉRIA  ENTREGADA");

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnCalificarTarea.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnCalificarTarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/calificar.png"))); // NOI18N
        btnCalificarTarea.setText("Calificar Tarea");
        btnCalificarTarea.setActionCommand("btnEditar");
        btnCalificarTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalificarTareaActionPerformed(evt);
            }
        });

        btnActualizarTablaTareasEntregadas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTablaTareasEntregadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTablaTareasEntregadas.setText("Actualizar");
        btnActualizarTablaTareasEntregadas.setActionCommand("btnEditar");
        btnActualizarTablaTareasEntregadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTablaTareasEntregadasActionPerformed(evt);
            }
        });

        btnIrATablaTareas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnIrATablaTareas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnIrATablaTareas.setText("Ir a Tareas");
        btnIrATablaTareas.setActionCommand("btnEditar");
        btnIrATablaTareas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrATablaTareasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(btnIrATablaTareas)
                .addGap(295, 295, 295)
                .addComponent(btnActualizarTablaTareasEntregadas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 338, Short.MAX_VALUE)
                .addComponent(btnCalificarTarea)
                .addGap(44, 44, 44))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIrATablaTareas)
                    .addComponent(btnActualizarTablaTareasEntregadas)
                    .addComponent(btnCalificarTarea))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTablaTareasEntregadas = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jTablaTareasEntregadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTablaTareasEntregadas.setFocusable(false);
        jTablaTareasEntregadas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane6.setViewportView(jTablaTareasEntregadas);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblMateriaEntregada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMateriaEntregada)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 391, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jTPanel.addTab("tab3", jPanel4);

        lblTarea.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTarea.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTarea.setText("TAREA");

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos tarea"));

        jLabel2.setText("Indicaciones de tarea:");

        txtIndicanionesTarea.setEditable(false);
        txtIndicanionesTarea.setColumns(20);
        txtIndicanionesTarea.setRows(5);
        jScrollPane4.setViewportView(txtIndicanionesTarea);

        jLabel3.setText("Desarrollo de tarea:");

        txtDesarrolloTarea.setEditable(false);
        txtDesarrolloTarea.setColumns(20);
        txtDesarrolloTarea.setRows(5);
        jScrollPane5.setViewportView(txtDesarrolloTarea);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel4.setText("Nota*");

        txtNotaTarea.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        txtNotaTarea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNotaTareaKeyTyped(evt);
            }
        });

        lblEstudiante.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblEstudiante.setText("Estudiante");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(lblEstudiante, javax.swing.GroupLayout.PREFERRED_SIZE, 986, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4)))
                        .addGap(21, 21, 21)
                        .addComponent(txtNotaTarea, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEstudiante)
                    .addComponent(jLabel4)
                    .addComponent(txtNotaTarea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnIrTablaTareasEntregadas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnIrTablaTareasEntregadas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnIrTablaTareasEntregadas.setText("Ir a Taras Entregadas");
        btnIrTablaTareasEntregadas.setActionCommand("btnEditar");
        btnIrTablaTareasEntregadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrTablaTareasEntregadasActionPerformed(evt);
            }
        });

        btnActualizarTarea.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTarea.setText("Actualizar");
        btnActualizarTarea.setActionCommand("btnEditar");
        btnActualizarTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTareaActionPerformed(evt);
            }
        });

        btnGuardarTareaEntregada.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnGuardarTareaEntregada.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/guardar.png"))); // NOI18N
        btnGuardarTareaEntregada.setText("Guardar");
        btnGuardarTareaEntregada.setActionCommand("btnEditar");
        btnGuardarTareaEntregada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarTareaEntregadaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(btnIrTablaTareasEntregadas)
                .addGap(258, 258, 258)
                .addComponent(btnActualizarTarea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnGuardarTareaEntregada)
                .addGap(50, 50, 50))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIrTablaTareasEntregadas)
                    .addComponent(btnGuardarTareaEntregada)
                    .addComponent(btnActualizarTarea))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTarea, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lblTarea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTPanel.addTab("tab4", jPanel5);

        jPanel10.setPreferredSize(new java.awt.Dimension(800, 400));

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro de Datos"));

        jLabel5.setText("Nombres*");

        jLabel6.setText("Indicaciones Tarea*");

        txtIndicacion.setColumns(20);
        txtIndicacion.setRows(5);
        txtIndicacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIndicacionKeyTyped(evt);
            }
        });
        jScrollPane7.setViewportView(txtIndicacion);

        jLabel9.setText("Creación*");

        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });

        jLabel15.setText("Entrega*");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 1166, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jDCreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jDEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap())
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jDCreacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jDEntrega, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnCancelar.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/cancelar.png"))); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.setActionCommand("btnEditar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnGuardarTarea.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnGuardarTarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/guardar.png"))); // NOI18N
        btnGuardarTarea.setText("Guardar");
        btnGuardarTarea.setActionCommand("btnEliminar");
        btnGuardarTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarTareaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(244, 244, 244)
                .addComponent(btnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnGuardarTarea)
                .addGap(246, 246, 246))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelar)
                    .addComponent(btnGuardarTarea))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTPanel.addTab("tab5", jPanel10);

        jPanel13.setPreferredSize(new java.awt.Dimension(800, 400));

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder("Ver Datos"));

        jLabel7.setText("Nombres:");

        jLabel8.setText("Indicaciones Tarea:");

        txtIndicacion1.setEditable(false);
        txtIndicacion1.setColumns(20);
        txtIndicacion1.setRows(5);
        jScrollPane8.setViewportView(txtIndicacion1);

        jLabel12.setText("Creación:");

        txtNombre1.setEditable(false);

        jDCreacion1.setEnabled(false);

        jDEntrega1.setEnabled(false);

        jLabel18.setText("Entrega:");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(147, 1112, Short.MAX_VALUE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre1)
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 1166, Short.MAX_VALUE)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jDCreacion1, javax.swing.GroupLayout.PREFERRED_SIZE, 589, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel14Layout.createSequentialGroup()
                                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jDEntrega1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNombre1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jDCreacion1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jDEntrega1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnSalir.setText("Ir a Tareas Entregadas");
        btnSalir.setActionCommand("btnEditar");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSalir)
                .addGap(552, 552, 552))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSalir)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTPanel.addTab("tab6", jPanel13);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTPanel)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTPanel)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmar, this.configGeneral.msjTitulConfirmar,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION) {
            dispose();
            new frmLogin().setVisible(true);
        }
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    private void btnActualizarTablaMateriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTablaMateriasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_materias";
        this.tipoTab();
    }//GEN-LAST:event_btnActualizarTablaMateriasActionPerformed

    private void btnIrTablaMateriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrTablaMateriasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_materias";
        this.tipoTab();
    }//GEN-LAST:event_btnIrTablaMateriasActionPerformed

    private void btnVerTareasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerTareasActionPerformed
        // TODO add your handling code here:
        int index = jTablaMaterias.getSelectedRow();
        if (index >= 0) {
            try {
                this.verMateriaId(jTablaMaterias.getValueAt(index, 0).toString());
                this._accion = "tabla_tareas";
                this.tipoTab();
            } catch (Exception ex) {
                Logger.getLogger(frmDocente.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnVerTareasActionPerformed

    private void btnCalificarTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalificarTareaActionPerformed
        // TODO add your handling code here:
        int index = jTablaTareasEntregadas.getSelectedRow();
        if (index >= 0) {
            try {
                this.verTareaEntregadaId(jTablaTareasEntregadas.getValueAt(index, 0).toString());
                this._accion = "calificar_tarea_entregada";
                this.tipoTab();
            } catch (Exception ex) {
                Logger.getLogger(frmDocente.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btnCalificarTareaActionPerformed

    private void btnVerTareasEntregadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerTareasEntregadasActionPerformed
        // TODO add your handling code here:
        int index = jTablaTareas.getSelectedRow();
        if (index >= 0) {
            try {
                this.verTareaId(jTablaTareas.getValueAt(index, 0).toString());
                this._accion = "tabla_tareas_entregadas";
                this.tipoTab();
            } catch (Exception ex) {
                Logger.getLogger(frmDocente.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnVerTareasEntregadasActionPerformed

    private void btnActualizarTablaTareasEntregadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTablaTareasEntregadasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_tareas_entregadas";
        this.tipoTab();
    }//GEN-LAST:event_btnActualizarTablaTareasEntregadasActionPerformed

    private void btnIrATablaTareasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrATablaTareasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_tareas";
        this.tipoTab();
    }//GEN-LAST:event_btnIrATablaTareasActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // TODO add your handling code here:
        this._accion = "nuevo_tarea";
        this.tipoTab();
        this.limpiarCamposTarea();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        int index = jTablaTareas.getSelectedRow();
        if (index >= 0) {
            try {
                this.limpiarCamposTarea();
                this.verTareaId(jTablaTareas.getValueAt(index, 0).toString());
                this._accion = "editar_tarea";
                this.tipoTab();
            } catch (Exception ex) {
                Logger.getLogger(frmDocente.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int index = jTablaTareas.getSelectedRow();
        if (index >= 0) {
            JDialog.setDefaultLookAndFeelDecorated(true);
            int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarEliminar, this.configGeneral.msjTitulConfirmar,
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                this.eliminarTarea(Integer.parseInt(jTablaTareas.getValueAt(index, 0).toString()));
                this._accion = "tabla_tareas";
                this.tipoTab();
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarCancelar, this.configGeneral.msjConfirmar,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION) {
            this._accion = "tabla_tareas";
            this.tipoTab();
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGuardarTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarTareaActionPerformed
        // TODO add your handling code here:
        if (this.validarCampos()) {
            JDialog.setDefaultLookAndFeelDecorated(true);
            int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarGuardar, this.configGeneral.msjTitulConfirmar,
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                if (this._accion.equals("nuevo_tarea")) {
                    this.guardarTarea();
                } else {
                    this.editarTarea(this._ID_Tarea);
                }
                this._accion = "tabla_tareas";
                this.tipoTab();
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjErrorLlenarTodosCampos, this.configGeneral.msjTituloAdvertencia, JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnGuardarTareaActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_tareas";
        this.tipoTab();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnActualizarTablaTareasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTablaTareasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_tareas";
        this.tipoTab();
    }//GEN-LAST:event_btnActualizarTablaTareasActionPerformed

    private void btnVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerActionPerformed
        // TODO add your handling code here:
        try {
            int index = jTablaTareas.getSelectedRow();
            if (index >= 0) {
                this.limpiarCamposTarea();
                this._accion = "ver_tarea";
                this.tipoTab();
                this.verTareaId(jTablaTareas.getValueAt(index, 0).toString());
            } else {
                JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            Logger.getLogger(frmDocente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnVerActionPerformed

    private void btnGuardarTareaEntregadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarTareaEntregadaActionPerformed
        // TODO add your handling code here:
        if (!txtNotaTarea.getText().trim().isEmpty()) {
            JDialog.setDefaultLookAndFeelDecorated(true);
            int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarGuardar, this.configGeneral.msjTitulConfirmar,
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                this.editarTareaEntregada(this._ID_TareaEntregada);
                this._accion = "tabla_tareas_entregadas";
                this.tipoTab();
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjErrorLlenarTodosCampos, this.configGeneral.msjTituloAdvertencia, JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnGuardarTareaEntregadaActionPerformed

    private void btnActualizarTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTareaActionPerformed
        try {
            // TODO add your handling code here:
            this.verTareaId(String.valueOf(this._ID_Tarea));
        } catch (Exception ex) {
            Logger.getLogger(frmDocente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnActualizarTareaActionPerformed

    private void btnIrTablaTareasEntregadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrTablaTareasEntregadasActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarCancelar, this.configGeneral.msjConfirmar,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION) {
            this._accion = "tabla_tareas_entregadas";
            this.tipoTab();
        }
    }//GEN-LAST:event_btnIrTablaTareasEntregadasActionPerformed

    private void txtNotaTareaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNotaTareaKeyTyped
        // TODO add your handling code here:
        int key = evt.getKeyChar();
        if (this.configGeneral.getLogitudNota(txtNotaTarea)) {
            evt.consume();
        }
        if (this.configGeneral.getkeyNota(txtNotaTarea, key)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNotaTareaKeyTyped

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        // TODO add your handling code here:
        int key = evt.getKeyChar();
        if (this.configGeneral.getLogitudNombre(txtNombre)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtIndicacionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIndicacionKeyTyped
        // TODO add your handling code here:
        int key = evt.getKeyChar();
        if (this.configGeneral.getLogitudIndicacion(txtIndicacion)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtIndicacionKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarTablaMaterias;
    private javax.swing.JButton btnActualizarTablaTareas;
    private javax.swing.JButton btnActualizarTablaTareasEntregadas;
    private javax.swing.JButton btnActualizarTarea;
    private javax.swing.JButton btnCalificarTarea;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardarTarea;
    private javax.swing.JButton btnGuardarTareaEntregada;
    private javax.swing.JButton btnIrATablaTareas;
    private javax.swing.JButton btnIrTablaMaterias;
    private javax.swing.JButton btnIrTablaTareasEntregadas;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnVer;
    private javax.swing.JButton btnVerTareas;
    private javax.swing.JButton btnVerTareasEntregadas;
    private com.toedter.calendar.JDateChooser jDCreacion;
    private com.toedter.calendar.JDateChooser jDCreacion1;
    private com.toedter.calendar.JDateChooser jDEntrega;
    private com.toedter.calendar.JDateChooser jDEntrega1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTPanel;
    private javax.swing.JTable jTablaMaterias;
    private javax.swing.JTable jTablaTareas;
    private javax.swing.JTable jTablaTareasEntregadas;
    private javax.swing.JLabel lblEstudiante;
    private javax.swing.JLabel lblMateria;
    private javax.swing.JLabel lblMateriaEntregada;
    private javax.swing.JLabel lblTarea;
    private javax.swing.JTextArea txtDesarrolloTarea;
    private javax.swing.JTextArea txtIndicacion;
    private javax.swing.JTextArea txtIndicacion1;
    private javax.swing.JTextArea txtIndicanionesTarea;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNombre1;
    private javax.swing.JTextField txtNotaTarea;
    // End of variables declaration//GEN-END:variables
}
