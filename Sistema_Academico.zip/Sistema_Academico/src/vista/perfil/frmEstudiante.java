/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista.perfil;

import configuraciones.Validaciones;
import controlador.MateriaBD;
import controlador.MatriculaBD;
import controlador.TareaBD;
import controlador.TareaEntregadaBD;
import java.awt.Component;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import modelo.Materia;
import modelo.Matricula;
import modelo.Rol;
import modelo.Tarea;
import modelo.TareaEntregada;
import modelo.Usuario;
import vista.frmLogin;

/**
 *
 * @author Baller
 */
public class frmEstudiante extends javax.swing.JFrame {

    /**
     * Creates new form frmEstudiante
     */
    Rol _objRol = new Rol();
    Usuario _objUsuario = new Usuario();
    Matricula _objMatricula = new Matricula();
    Materia _objMateria = new Materia();
    Tarea _objTarera = new Tarea();
    TareaEntregada _objTareaEntregada = new TareaEntregada();

    JPanel _jp;
    Component _compenteTablaMatriculas;
    Component _compenteVerMaterias;
    Component _compenteVerTareas;
    Component _compenteEntregarTarea;

    String _accion;
    String _accionTareaEntregada;
    int _ID_Matricula = 0;
    int _ID_Materia = 0;
    int _ID_Tarea = 0;
    int _ID_TareaEntregada = 0;
    int _ID_Usuario = 0;

    Validaciones configGeneral;

    public frmEstudiante(Rol rol, Usuario usuario) {
        initComponents();
        this.configGeneral = new Validaciones();
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);// desavilita el boton de cerrar en ventana
        this.setResizable(false);//deshabilita botón maximizar
        this.setLocationRelativeTo(null);

        ///Cargamos los datos del Usuario
        this._objRol = rol;
        this._objUsuario = usuario;
        this._ID_Usuario = usuario.getId();

        //Obtenemos los componetes del panel para cada accion de la administración
        this._compenteTablaMatriculas = jTPanel.getComponentAt(0);
        this._compenteVerMaterias = jTPanel.getComponentAt(1);
        this._compenteVerTareas = jTPanel.getComponentAt(2);
        this._compenteEntregarTarea = jTPanel.getComponentAt(3);

        this._accion = "tabla_matricula";
        this.tipoTab();
    }

    private void tipoTab() {
        if (this._accion.equals("tabla_matricula")) {
            jTPanel.remove(this._compenteTablaMatriculas);
            jTPanel.remove(this._compenteVerMaterias);
            jTPanel.remove(this._compenteVerTareas);
            jTPanel.remove(this._compenteEntregarTarea);

            jTPanel.add(this._compenteTablaMatriculas);
            jTPanel.setTitleAt(0, "VER MATRÍCULAS");
            this.cargarTablaMatriculas(this._objUsuario.getId());
        } else {
            if (this._accion.equals("tabla_materia")) {
                jTPanel.remove(this._compenteTablaMatriculas);
                jTPanel.remove(this._compenteVerTareas);
                jTPanel.add(this._compenteVerMaterias);
                jTPanel.setTitleAt(0, "VER MATÉRIAS");
                this.cargarTablaMateriaIDCurso(this._objMatricula.getIdCurso());
            } else {
                if (this._accion.equals("tabla_tarea")) {
                    jTPanel.remove(this._compenteVerMaterias);
                    jTPanel.remove(this._compenteEntregarTarea);
                    jTPanel.add(this._compenteVerTareas);
                    jTPanel.setTitleAt(0, "VER TAREAS");
                    this.cargarTablaTareaIDMateria(this._objMateria.getId());
                } else {
                    if (this._accion.equals("entregar_tarea")) {
                        jTPanel.remove(this._compenteVerTareas);
//                        jTPanel.remove(this._compenteVerTareas);
                        jTPanel.add(this._compenteEntregarTarea);
                        jTPanel.setTitleAt(0, "ENTREGAR TAREA");
                    }
                }
            }
        }
    }

    /* --------------- CARGAR TABLAS ------------------*/
    private void cargarTablaMatriculas(int id_estudiante) {
        try {
            MatriculaBD objBD = new MatriculaBD();
            jTablaMatriculas.setModel(objBD.getTablaIDEstudiante(String.valueOf(id_estudiante)));
        } catch (SQLException ex) {
            System.err.println(this.configGeneral.errorCargaTabla + ex.getMessage());
        } finally {
            jTablaMatriculas.getColumnModel().getColumn(0).setMaxWidth(0);//ancho columna de ID
            jTablaMatriculas.getColumnModel().getColumn(1).setMaxWidth(40);//ancho columna de N°
            jTablaMatriculas.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        }
    }

    private void cargarTablaMateriaIDCurso(int id_curso) {
        try {
            MateriaBD objBD = new MateriaBD();
            jTablaMaterias.setModel(objBD.getTablaMateriaIDCursoIDEstudiante(String.valueOf(id_curso), String.valueOf(this._ID_Usuario)));
        } catch (SQLException ex) {
            System.err.println(this.configGeneral.errorCargaTabla + ex.getMessage());
        } finally {
            jTablaMaterias.getColumnModel().getColumn(0).setMaxWidth(0);//ancho columna de ID
            jTablaMaterias.getColumnModel().getColumn(1).setMaxWidth(40);//ancho columna de N°
            jTablaMaterias.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        }
    }

    private void cargarTablaTareaIDMateria(int id_materia) {
        try {
            TareaBD objBD = new TareaBD();
            jTablaTareas.setModel(objBD.getTablaTareaIDMateria(String.valueOf(id_materia), String.valueOf(this._ID_Usuario)));
        } catch (SQLException ex) {
            System.err.println(this.configGeneral.errorCargaTabla + ex.getMessage());
        } finally {
            jTablaTareas.getColumnModel().getColumn(0).setMaxWidth(0);//ancho columna de ID
            jTablaTareas.getColumnModel().getColumn(1).setMaxWidth(40);//ancho columna de N°
            jTablaMaterias.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        }
    }


    /* --------------- VER DATOS ------------------*/
    private void verMatriculaId(String id_matricula) throws Exception {
        Matricula obj = new Matricula();
        try {
            MatriculaBD objBD = new MatriculaBD();
            obj = objBD.getMatriculaID(id_matricula);

        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposMatricula(obj);
        }
    }

    private void verMateriaId(String id_materia) throws Exception {
        Materia obj = new Materia();
        try {
            MateriaBD objBD = new MateriaBD();
            obj = objBD.getMateriaID(id_materia);

        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposMateria(obj);
        }
    }

    private void verTareaId(String id_tarea) throws Exception {
        Tarea obj = new Tarea();
        try {
            TareaBD objBD = new TareaBD();
            obj = objBD.getTareaID(id_tarea);

        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposTarea(obj);
        }
    }

    private void verTareaEntregadaIdEstudianteIdTarea(String id_estudiente, String id_tarea) throws Exception {
        TareaEntregada obj = new TareaEntregada();
        try {
            TareaEntregadaBD objBD = new TareaEntregadaBD();
            obj = objBD.getTareaEntregadaIDEstudianteIdTarea(id_estudiente, id_tarea);
        } catch (Exception ex) {
            System.err.println(this.configGeneral.errorVerId + ex.getMessage());
        } finally {
            this.cargarCamposTareaEntrega(obj);
        }
    }


    /* --------------- CARGAR CAMPOS ------------------*/
    private void cargarCamposMatricula(Matricula obj) throws Exception {
        this._objMatricula = obj;
        this._ID_Matricula = obj.getId();
        //para nuevo
        lblCurso.setText("CURSO: " + obj.getNombreCurso());
        lblNumeroMatricula.setText("MATRÍCULA: #" + obj.getNumeroMatricula());

    }

    private void cargarCamposMateria(Materia obj) throws Exception {
        this._objMateria = obj;
        this._ID_Materia = obj.getId();
        //para nuevo
        lblMateria.setText(obj.getNombre());

    }

    private void cargarCamposTarea(Tarea obj) throws Exception {
        this._objTarera = obj;
        this._ID_Tarea = obj.getId();
        //para nuevo
        lblTarea.setText(obj.getNombre());
        txtIndicanionesTarea.setText(obj.getDescripcion());
        txtNotaTarea.setText("0.00");
    }

    private void cargarCamposTareaEntrega(TareaEntregada obj) throws Exception {
        this._objTareaEntregada = obj;
        this._ID_TareaEntregada = obj.getId();
        //para nuevo
        txtDesarrolloTarea.setText(obj.getDescripcion());
        txtNotaTarea.setText(String.valueOf(obj.getNota_entregada()));
    }

    /* --------------- ADMINISTRAR TAREA ENVIADA ------------------*/
    private void guardarTareaEntregada() {
        TareaEntregada obj = new TareaEntregada();
        TareaEntregadaBD objBD = new TareaEntregadaBD();
        obj.setIdEstudiante(this._ID_Usuario);
        obj.setIdTarea(this._ID_Tarea);
        obj.setNota_entregada(Double.parseDouble(txtNotaTarea.getText()));
        obj.setDescripcion(txtDesarrolloTarea.getText());
        obj.setEstado("A");
        objBD.guardar(obj);
    }

    private void editarTareaEntregada(int ID) {
        TareaEntregada obj = new TareaEntregada();
        TareaEntregadaBD objBD = new TareaEntregadaBD();
        obj.setId(ID);
        obj.setIdEstudiante(this._ID_Usuario);
        obj.setIdTarea(this._ID_Tarea);
        obj.setNota_entregada(Double.parseDouble(txtNotaTarea.getText()));
        obj.setDescripcion(txtDesarrolloTarea.getText());
        objBD.editar(obj);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTPanel = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablaMatriculas = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        btnVerMatricula = new javax.swing.JButton();
        btnCerrarSesion = new javax.swing.JButton();
        btnActualizarTablaMatriculas = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblCurso = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTablaMaterias = new javax.swing.JTable();
        lblNumeroMatricula = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        btnIrTablaMatriculas = new javax.swing.JButton();
        btnActualizarTablaMaterias = new javax.swing.JButton();
        btnVerTareas = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        lblMateria = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTablaTareas = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        btnIrTablaMaterias = new javax.swing.JButton();
        btnActualizarTablaTareas = new javax.swing.JButton();
        btnEntregarTarea = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        lblTarea = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtIndicanionesTarea = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtDesarrolloTarea = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        txtNotaTarea = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        btnIrTablaTareas = new javax.swing.JButton();
        btnActualizarTarea = new javax.swing.JButton();
        btnEnviarTarea = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTablaMatriculas = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jTablaMatriculas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTablaMatriculas.setFocusable(false);
        jTablaMatriculas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(jTablaMatriculas);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnVerMatricula.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnVerMatricula.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/lista.png"))); // NOI18N
        btnVerMatricula.setText("Listar Materias");
        btnVerMatricula.setActionCommand("btnEditar");
        btnVerMatricula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerMatriculaActionPerformed(evt);
            }
        });

        btnCerrarSesion.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnCerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/cerra_sesion.png"))); // NOI18N
        btnCerrarSesion.setText("Cerrar Sesión");
        btnCerrarSesion.setIconTextGap(1);
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });

        btnActualizarTablaMatriculas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTablaMatriculas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTablaMatriculas.setText("Actualizar");
        btnActualizarTablaMatriculas.setActionCommand("btnEditar");
        btnActualizarTablaMatriculas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTablaMatriculasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btnCerrarSesion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 391, Short.MAX_VALUE)
                .addComponent(btnActualizarTablaMatriculas)
                .addGap(308, 308, 308)
                .addComponent(btnVerMatricula)
                .addGap(21, 21, 21))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCerrarSesion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnActualizarTablaMatriculas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVerMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 12, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MIS MATRÍCULAS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 416, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        jTPanel.addTab("tab1", jPanel1);

        lblCurso.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblCurso.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCurso.setText("CURSO");

        jTablaMaterias = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jTablaMaterias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTablaMaterias.setFocusable(false);
        jTablaMaterias.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane2.setViewportView(jTablaMaterias);

        lblNumeroMatricula.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblNumeroMatricula.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNumeroMatricula.setText("# MATRÍCULA");

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnIrTablaMatriculas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnIrTablaMatriculas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnIrTablaMatriculas.setText("Ir a Matrículas");
        btnIrTablaMatriculas.setActionCommand("btnEditar");
        btnIrTablaMatriculas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrTablaMatriculasActionPerformed(evt);
            }
        });

        btnActualizarTablaMaterias.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTablaMaterias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTablaMaterias.setText("Actualizar");
        btnActualizarTablaMaterias.setActionCommand("btnEditar");
        btnActualizarTablaMaterias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTablaMateriasActionPerformed(evt);
            }
        });

        btnVerTareas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnVerTareas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/lista.png"))); // NOI18N
        btnVerTareas.setText("Listar Tareas");
        btnVerTareas.setActionCommand("btnEditar");
        btnVerTareas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerTareasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(btnIrTablaMatriculas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 339, Short.MAX_VALUE)
                .addComponent(btnActualizarTablaMaterias)
                .addGap(340, 340, 340)
                .addComponent(btnVerTareas)
                .addGap(31, 31, 31))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btnIrTablaMatriculas)
                .addComponent(btnActualizarTablaMaterias)
                .addComponent(btnVerTareas))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCurso, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblNumeroMatricula, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCurso)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNumeroMatricula)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTPanel.addTab("tab2", jPanel2);

        lblMateria.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblMateria.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMateria.setText("MATERIA");

        jTablaTareas = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        jTablaTareas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTablaTareas.setFocusable(false);
        jTablaTareas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane3.setViewportView(jTablaTareas);

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnIrTablaMaterias.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnIrTablaMaterias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnIrTablaMaterias.setText("Ir a Matérias");
        btnIrTablaMaterias.setActionCommand("btnEditar");
        btnIrTablaMaterias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrTablaMateriasActionPerformed(evt);
            }
        });

        btnActualizarTablaTareas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTablaTareas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTablaTareas.setText("Actualizar");
        btnActualizarTablaTareas.setActionCommand("btnEditar");
        btnActualizarTablaTareas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTablaTareasActionPerformed(evt);
            }
        });

        btnEntregarTarea.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnEntregarTarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/entregar_tarea.png"))); // NOI18N
        btnEntregarTarea.setText("Entregar Tarea");
        btnEntregarTarea.setActionCommand("btnEditar");
        btnEntregarTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntregarTareaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(btnIrTablaMaterias)
                .addGap(331, 331, 331)
                .addComponent(btnActualizarTablaTareas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 360, Short.MAX_VALUE)
                .addComponent(btnEntregarTarea)
                .addGap(34, 34, 34))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIrTablaMaterias)
                    .addComponent(btnActualizarTablaTareas)
                    .addComponent(btnEntregarTarea))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(lblMateria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lblMateria)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jTPanel.addTab("tab3", jPanel4);

        lblTarea.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTarea.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTarea.setText("TAREA");

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos tarea"));

        jLabel2.setText("Indicaciones de tarea:");

        txtIndicanionesTarea.setEditable(false);
        txtIndicanionesTarea.setColumns(20);
        txtIndicanionesTarea.setRows(5);
        jScrollPane4.setViewportView(txtIndicanionesTarea);

        jLabel3.setText("Desarrollo de tarea*");

        txtDesarrolloTarea.setColumns(20);
        txtDesarrolloTarea.setRows(5);
        txtDesarrolloTarea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDesarrolloTareaKeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(txtDesarrolloTarea);

        jLabel4.setText("Nota:");

        txtNotaTarea.setEditable(false);
        txtNotaTarea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNotaTareaKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txtNotaTarea, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane5)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNotaTarea, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(16, 16, 16))
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Acciones:"));

        btnIrTablaTareas.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnIrTablaTareas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/salir.png"))); // NOI18N
        btnIrTablaTareas.setText("Ir a Tareas");
        btnIrTablaTareas.setActionCommand("btnEditar");
        btnIrTablaTareas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIrTablaTareasActionPerformed(evt);
            }
        });

        btnActualizarTarea.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnActualizarTarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/actualizar.png"))); // NOI18N
        btnActualizarTarea.setText("Actualizar");
        btnActualizarTarea.setActionCommand("btnEditar");
        btnActualizarTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTareaActionPerformed(evt);
            }
        });

        btnEnviarTarea.setFont(new java.awt.Font("Segoe UI", 3, 13)); // NOI18N
        btnEnviarTarea.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/32px/enviar_tarea.png"))); // NOI18N
        btnEnviarTarea.setText("Enviar Tarea");
        btnEnviarTarea.setActionCommand("btnEditar");
        btnEnviarTarea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarTareaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(btnIrTablaTareas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 392, Short.MAX_VALUE)
                .addComponent(btnActualizarTarea)
                .addGap(334, 334, 334)
                .addComponent(btnEnviarTarea)
                .addGap(25, 25, 25))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIrTablaTareas)
                    .addComponent(btnActualizarTarea)
                    .addComponent(btnEnviarTarea))
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblTarea, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(lblTarea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jTPanel.addTab("tab4", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTPanel)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTPanel)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVerMatriculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerMatriculaActionPerformed
        // TODO add your handling code here:
        int index = jTablaMatriculas.getSelectedRow();
        if (index >= 0) {
//            this.limpiarCampos();
            try {
                this.verMatriculaId(jTablaMatriculas.getValueAt(index, 0).toString());
                this._accion = "tabla_materia";
                this.tipoTab();
            } catch (Exception ex) {
                Logger.getLogger(frmEstudiante.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnVerMatriculaActionPerformed

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmar, this.configGeneral.msjTitulConfirmar,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION) {
            dispose();
            new frmLogin().setVisible(true);
        }
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    private void btnActualizarTablaMatriculasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTablaMatriculasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_matricula";
        this.tipoTab();
    }//GEN-LAST:event_btnActualizarTablaMatriculasActionPerformed

    private void btnIrTablaMatriculasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrTablaMatriculasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_matricula";
        this.tipoTab();
    }//GEN-LAST:event_btnIrTablaMatriculasActionPerformed

    private void btnActualizarTablaMateriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTablaMateriasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_materia";
        this.tipoTab();
    }//GEN-LAST:event_btnActualizarTablaMateriasActionPerformed

    private void btnVerTareasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerTareasActionPerformed
        // TODO add your handling code here:
        int index = jTablaMaterias.getSelectedRow();
        if (index >= 0) {
//            this.limpiarCampos();
            try {
                this.verMateriaId(jTablaMaterias.getValueAt(index, 0).toString());
                this._accion = "tabla_tarea";
                this.tipoTab();
            } catch (Exception ex) {
                Logger.getLogger(frmEstudiante.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnVerTareasActionPerformed

    private void btnIrTablaMateriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrTablaMateriasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_materia";
        this.tipoTab();
    }//GEN-LAST:event_btnIrTablaMateriasActionPerformed

    private void btnActualizarTablaTareasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTablaTareasActionPerformed
        // TODO add your handling code here:
        this._accion = "tabla_tarea";
        this.tipoTab();
    }//GEN-LAST:event_btnActualizarTablaTareasActionPerformed

    private void btnEntregarTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntregarTareaActionPerformed
        // TODO add your handling code here:
        try {
            int index = jTablaTareas.getSelectedRow();
            if (index >= 0) {
                Date fechaActual = new Date();
                Date fechaEntrega = new SimpleDateFormat("yyyy-MM-dd").parse(jTablaTareas.getValueAt(index, 4).toString());
                if (this.configGeneral.getStringDate(fechaActual).equals(this.configGeneral.getStringDate(fechaEntrega)) || fechaActual.before(fechaEntrega)) {
                    this.verTareaId(jTablaTareas.getValueAt(index, 0).toString());
                    this.verTareaEntregadaIdEstudianteIdTarea(String.valueOf(this._ID_Usuario), String.valueOf(this._ID_Tarea));
                    if (this._ID_TareaEntregada > 0) {
                        this._accionTareaEntregada = "editar";
                    } else {
                        this._accionTareaEntregada = "nuevo";
                    }
                    this._accion = "entregar_tarea";
                    this.tipoTab();
                } else {
                    JOptionPane.showMessageDialog(null, this.configGeneral.errorFechaActualMayorFechaEntraTarea);
                }
            } else {
                JOptionPane.showMessageDialog(null, this.configGeneral.msjSeleccioneFila, this.configGeneral.msjTitulInformativo, JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (ParseException ex) {
            Logger.getLogger(frmEstudiante.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(frmEstudiante.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnEntregarTareaActionPerformed

    private void txtNotaTareaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNotaTareaKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNotaTareaKeyTyped

    private void btnEnviarTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarTareaActionPerformed
        // TODO add your handling code here:
        if (!txtDesarrolloTarea.getText().trim().isEmpty()) {
            JDialog.setDefaultLookAndFeelDecorated(true);
            int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarEnviarTarea, this.configGeneral.msjTitulConfirmar,
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (response == JOptionPane.YES_OPTION) {
                if (this._accionTareaEntregada.equals("nuevo")) {
                    this.guardarTareaEntregada();
                } else {
                    this.editarTareaEntregada(this._ID_TareaEntregada);
                }

                this._accion = "tabla_tarea";
                this.tipoTab();
            }
        } else {
            JOptionPane.showMessageDialog(null, this.configGeneral.msjErrorLlenarTodosCampos, this.configGeneral.msjTituloAdvertencia, JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnEnviarTareaActionPerformed

    private void btnActualizarTareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTareaActionPerformed
        try {
            // TODO add your handling code here:
            this.verTareaId(String.valueOf(this._ID_Tarea));
        } catch (Exception ex) {
            Logger.getLogger(frmEstudiante.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnActualizarTareaActionPerformed

    private void btnIrTablaTareasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIrTablaTareasActionPerformed
        // TODO add your handling code here:
        JDialog.setDefaultLookAndFeelDecorated(true);
        int response = JOptionPane.showConfirmDialog(null, this.configGeneral.msjConfirmarCancelar, this.configGeneral.msjConfirmar,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION) {
            this._accion = "tabla_tarea";
            this.tipoTab();
        }
    }//GEN-LAST:event_btnIrTablaTareasActionPerformed

    private void txtDesarrolloTareaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDesarrolloTareaKeyTyped
        // TODO add your handling code here:
        int key = evt.getKeyChar();
        if (this.configGeneral.getLogitudIndicacion(txtDesarrolloTarea)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtDesarrolloTareaKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarTablaMaterias;
    private javax.swing.JButton btnActualizarTablaMatriculas;
    private javax.swing.JButton btnActualizarTablaTareas;
    private javax.swing.JButton btnActualizarTarea;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnEntregarTarea;
    private javax.swing.JButton btnEnviarTarea;
    private javax.swing.JButton btnIrTablaMaterias;
    private javax.swing.JButton btnIrTablaMatriculas;
    private javax.swing.JButton btnIrTablaTareas;
    private javax.swing.JButton btnVerMatricula;
    private javax.swing.JButton btnVerTareas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTPanel;
    private javax.swing.JTable jTablaMaterias;
    private javax.swing.JTable jTablaMatriculas;
    private javax.swing.JTable jTablaTareas;
    private javax.swing.JLabel lblCurso;
    private javax.swing.JLabel lblMateria;
    private javax.swing.JLabel lblNumeroMatricula;
    private javax.swing.JLabel lblTarea;
    private javax.swing.JTextArea txtDesarrolloTarea;
    private javax.swing.JTextArea txtIndicanionesTarea;
    private javax.swing.JTextField txtNotaTarea;
    // End of variables declaration//GEN-END:variables
}
