/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Materia;

/**
 *
 * @author Baller
 */
public class MateriaBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public MateriaBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("NOTA");
            tabla.addColumn("CARRERA");
            tabla.addColumn("CURSO");
            tabla.addColumn("DOCENTE");

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.ma_nota NOTA, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA, \n"
                    + " d.id ID_DOCENTE, d.nombre NOMBRE_DOCENTE, d.apellido APELLIDO_DOCENTE \n"
                    + " FROM " + this.configGeneral.TABLA_MATERIA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " d  ON  m.id_docente = d.id \n"
                    + " WHERE m.estado='A' ORDER BY ca.nombre, m.nombre ASC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOTA");
                    datos[4] = r.getString("NOMBRE_CARRERA");
                    datos[5] = r.getString("NOMBRE_CURSO");
                    datos[6] = r.getString("NOMBRE_DOCENTE") + " " + r.getString("APELLIDO_DOCENTE");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public DefaultTableModel getTablaMateriaIDCursoIDEstudiante(String id_curso, String id_estudiante) throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("CARRERA");
            tabla.addColumn("DOCENTE");
            tabla.addColumn("PROMEDIO");

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.ma_nota NOTA, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA, \n"
                    + " d.id ID_DOCENTE, d.nombre NOMBRE_DOCENTE, d.apellido APELLIDO_DOCENTE \n"
                    + " FROM " + this.configGeneral.TABLA_MATERIA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " d  ON  m.id_docente = d.id \n"
                    + " WHERE m.estado='A' AND c.id=" + id_curso + " ORDER BY c.nombre, m.nombre ASC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[6];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOMBRE_CARRERA");
                    datos[4] = r.getString("NOMBRE_DOCENTE") + " " + r.getString("APELLIDO_DOCENTE");
                    TareaBD objBD = new TareaBD();
                    datos[5] = String.valueOf(objBD.getPromedioNotaTareasIDMateriaIDEstudiante(r.getString("ID"), id_estudiante));
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public DefaultTableModel getTablaMateriaIDDocente(String id_docente) throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("NOTA MININMA");
            tabla.addColumn("CARRERA");
            tabla.addColumn("CURSO");

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.ma_nota NOTA, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA, \n"
                    + " d.id ID_DOCENTE, d.nombre NOMBRE_DOCENTE, d.apellido APELLIDO_DOCENTE \n"
                    + " FROM " + this.configGeneral.TABLA_MATERIA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " d  ON  m.id_docente = d.id \n"
                    + " WHERE m.estado='A' AND d.id=" + id_docente + " ORDER BY ca.nombre, m.nombre ASC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOTA");
                    datos[4] = r.getString("NOMBRE_CARRERA");
                    datos[5] = r.getString("NOMBRE_CURSO");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Materia> getLista() throws SQLException {
        ArrayList<Materia> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.ma_nota NOTA, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA, \n"
                    + " d.id ID_DOCENTE, d.nombre NOMBRE_DOCENTE, d.apellido APELLIDO_DOCENTE \n"
                    + " FROM " + this.configGeneral.TABLA_MATERIA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " d  ON  m.id_docente = d.id \n"
                    + " WHERE m.estado='A' ORDER BY ca.nombre, m.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Materia obj = new Materia();
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNota(r.getDouble("NOTA"));
                    obj.setNombreCurso(r.getString("NOMBRE_CURSO") + " - " + r.getString("NOMBRE_CARRERA"));
                    obj.setIdCurso(r.getInt("ID_CURSO"));
                    obj.setNombreDocente(r.getString("NOMBRE_DOCENTE") + " " + r.getString("APELLIDO_DOCENTE"));
                    obj.setIdDocente(r.getInt("ID_DOCENTE"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Double getPromedioMateriasIDCursoIDEstudiante(String id_curso, String id_estudiante) throws SQLException {
        int totalMaterias = 0;
        Double sumaNotaMaterias = 0.0;
        Double promedio = 0.0;

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.ma_nota NOTA, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA, \n"
                    + " d.id ID_DOCENTE, d.nombre NOMBRE_DOCENTE, d.apellido APELLIDO_DOCENTE \n"
                    + " FROM " + this.configGeneral.TABLA_MATERIA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " d  ON  m.id_docente = d.id \n"
                    + " WHERE m.estado='A' AND c.id=" + id_curso + " ORDER BY c.nombre, m.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    totalMaterias++;
                    TareaBD objBD = new TareaBD();
                    sumaNotaMaterias += objBD.getPromedioNotaTareasIDMateriaIDEstudiante(r.getString("ID"), id_estudiante);
                }
            }
            promedio = sumaNotaMaterias / totalMaterias;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            promedio = 0.0;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            promedio = 0.0;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return Math.round(promedio * 100.0) / 100.0;
    }

    public Materia getMateriaID(String id) {
        Materia obj = new Materia();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();
        try {

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.ma_nota NOTA, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA, \n"
                    + " d.id ID_DOCENTE, d.nombre NOMBRE_DOCENTE, d.apellido APELLIDO_DOCENTE \n"
                    + " FROM " + this.configGeneral.TABLA_MATERIA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " d  ON  m.id_docente = d.id \n"
                    + " WHERE m.estado='A' AND m.id=" + id + " ORDER BY ca.nombre, m.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNota(r.getDouble("NOTA"));
                    obj.setNombreCurso(r.getString("NOMBRE_CURSO") + " - " + r.getString("NOMBRE_CARRERA"));
                    obj.setIdCurso(r.getInt("ID_CURSO"));
                    obj.setNombreDocente(r.getString("NOMBRE_DOCENTE") + " " + r.getString("APELLIDO_DOCENTE"));
                    obj.setIdDocente(r.getInt("ID_DOCENTE"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Materia obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();
            String sql = "INSERT INTO " + this.configGeneral.TABLA_MATERIA + " "
                    + "(NOMBRE, DESCRIPCION, ESTADO, MA_NOTA, ID_CURSO, ID_DOCENTE) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setString(3, obj.getEstado());
            preparedStatement.setDouble(4, obj.getNota());
            preparedStatement.setInt(5, obj.getIdCurso());
            preparedStatement.setInt(6, obj.getIdDocente());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Materia obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_MATERIA + " SET "
                    + "NOMBRE = ?, "
                    + "DESCRIPCION = ?, "
                    + "MA_NOTA = ?, "
                    + "ID_CURSO = ?, "
                    + "ID_DOCENTE = ? "
                    + "WHERE ID = ?";

            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setDouble(3, obj.getNota());
            preparedStatement.setInt(4, obj.getIdCurso());
            preparedStatement.setInt(5, obj.getIdDocente());
            preparedStatement.setInt(6, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Materia obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_MATERIA + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
