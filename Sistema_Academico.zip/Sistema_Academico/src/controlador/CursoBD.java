/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Curso;

/**
 *
 * @author Baller
 */
public class CursoBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public CursoBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("CARRERA");
//            tabla.addColumn("ESTADO");
            String sql = "SELECT cu.id ID, cu.nombre NOMBRE, cu.descripcion DESCRIPCION,\n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_CURSO + " cu\n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  cu.id_carrera = ca.id\n"
                    + " WHERE cu.estado='A' ORDER BY ca.nombre, cu.nombre ASC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[4];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOMBRE_CARRERA");
//                datos[3] = r.getString("ESTADO");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Curso> getLista() throws SQLException {
        ArrayList<Curso> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT cu.id ID, cu.nombre NOMBRE, cu.descripcion DESCRIPCION,\n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_CURSO + " cu\n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  cu.id_carrera = ca.id\n"
                    + " WHERE cu.estado='A' ORDER BY ca.nombre, cu.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Curso obj = new Curso();
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNombreCarrera(r.getString("NOMBRE_CARRERA"));
                    obj.setIdCarrera(r.getInt("ID_CARRERA"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Curso getCursoID(String id) {
        Curso obj = new Curso();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();
        try {

            String sql = "SELECT cu.id ID, cu.nombre NOMBRE, cu.descripcion DESCRIPCION,\n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_CURSO + " cu\n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  cu.id_carrera = ca.id\n"
                    + " WHERE cu.estado='A' AND cu.id=" + id + " ORDER BY ca.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNombreCarrera(r.getString("NOMBRE_CARRERA"));
                    obj.setIdCarrera(r.getInt("ID_CARRERA"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Curso obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "INSERT INTO " + this.configGeneral.TABLA_CURSO + " "
                    + "(NOMBRE, DESCRIPCION, ESTADO, ID_CARRERA) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setString(3, obj.getEstado());
            preparedStatement.setInt(4, obj.getIdCarrera());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Curso obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_CURSO + " SET "
                    + "NOMBRE = ?, "
                    + "DESCRIPCION = ?, "
                    + "ID_CARRERA = ? "
                    + "WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setInt(3, obj.getIdCarrera());
            preparedStatement.setInt(4, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Curso obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_CURSO + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
