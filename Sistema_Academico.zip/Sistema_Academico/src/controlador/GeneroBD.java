/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Genero;

/**
 *
 * @author Baller
 */
public class GeneroBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public GeneroBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("DESCRIPCIÓN");
//            tabla.addColumn("ESTADO");

            String sql = "SELECT * FROM " + this.configGeneral.TABLA_GENERO + " WHERE estado='A' order by nombre";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[4];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("id");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("nombre");
                    datos[3] = r.getString("descripcion");
//                datos[3] = r.getString("ESTADO");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Genero> getLista() throws SQLException {
        ArrayList<Genero> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT * FROM " + this.configGeneral.TABLA_GENERO + " WHERE estado='A' order by nombre";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Genero obj = new Genero();
                    obj.setId(r.getInt("id"));
                    obj.setNombre(r.getString("nombre"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Genero getGeneroID(String id) {
        Genero obj = new Genero();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();

        try {
            String sql = "SELECT * FROM " + this.configGeneral.TABLA_GENERO + " WHERE id=" + id;
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("id"));
                    obj.setNombre(r.getString("nombre"));
                    obj.setDescripcion(r.getString("descripcion"));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Genero obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "INSERT INTO " + this.configGeneral.TABLA_GENERO + " (nombre, descripcion, ESTADO) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setString(3, obj.getEstado());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Genero obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_GENERO + " SET "
                    + "NOMBRE = ?, DESCRIPCION = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setInt(3, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Genero obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_GENERO + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
