/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Matricula;

/**
 *
 * @author Baller
 */
public class MatriculaBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public MatriculaBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("ESTADO MATRÍCULA");
            tabla.addColumn("NOTA");
            tabla.addColumn("CARRERA");
            tabla.addColumn("CURSO");
            tabla.addColumn("ESTUDIANTE");
            tabla.addColumn("ESTADO ESTUDIANTE");
            tabla.addColumn("INICIO");
            tabla.addColumn("CULMINACIÓN");

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.mt_numero_matricula NUMERO_MATRICULA, m.mt_estado_estudiante ESTADO_ESTUDIANTE, m.mt_nota_final NOTA_FINAL, m.mt_fecha_inicio FECHA_INICIO, m.mt_fecha_culminacion FECHA_CULMINACION, m.mt_estado_matricula ESTADO_MATRICULA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_MATRICULA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  m.id_estudiante = e.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " WHERE m.estado='A' ORDER BY ca.nombre, c.nombre, m.nombre, m.mt_fecha_culminacion ASC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                String datos[] = new String[11];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("ESTADO_MATRICULA");
                    datos[4] = r.getString("NOTA_FINAL");
                    datos[5] = r.getString("NOMBRE_CARRERA");
                    datos[6] = r.getString("NOMBRE_CURSO");
                    datos[7] = r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE");
                    datos[8] = r.getString("ESTADO_ESTUDIANTE");
                    datos[9] = this.configGeneral.getStringDate(r.getDate("FECHA_INICIO"));
                    datos[10] = this.configGeneral.getStringDate(r.getDate("FECHA_CULMINACION"));
                    tabla.addRow(datos);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public DefaultTableModel getTablaIDEstudiante(String id_estudiante) throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("CARRERA");
            tabla.addColumn("CURSO");
            tabla.addColumn("PROMEDIO");
            tabla.addColumn("ESTADO MATRÍCULA");
            tabla.addColumn("ESTADO ESTUDIANTE");
            tabla.addColumn("INICIO");
            tabla.addColumn("CULMINACIÓN");

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.mt_numero_matricula NUMERO_MATRICULA, m.mt_estado_estudiante ESTADO_ESTUDIANTE, m.mt_nota_final NOTA_FINAL, m.mt_fecha_inicio FECHA_INICIO, m.mt_fecha_culminacion FECHA_CULMINACION, m.mt_estado_matricula ESTADO_MATRICULA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_MATRICULA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  m.id_estudiante = e.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " WHERE m.estado='A' AND e.id=" + id_estudiante + " ORDER BY ca.nombre, c.nombre, m.nombre ASC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                String datos[] = new String[10];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOMBRE_CARRERA");
                    datos[4] = r.getString("NOMBRE_CURSO");
                    MateriaBD objBD = new MateriaBD();
                    Double notaFinal = objBD.getPromedioMateriasIDCursoIDEstudiante(r.getString("ID_CURSO"), id_estudiante);
                    datos[5] = String.valueOf(notaFinal);
                    this.editarNotaFinal(r.getInt("ID"), notaFinal);

                    datos[6] = r.getString("ESTADO_MATRICULA");
                    datos[7] = r.getString("ESTADO_ESTUDIANTE");
                    datos[8] = this.configGeneral.getStringDate(r.getDate("FECHA_INICIO"));
                    datos[9] = this.configGeneral.getStringDate(r.getDate("FECHA_CULMINACION"));
                    tabla.addRow(datos);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Matricula> getLista() throws SQLException {
        ArrayList<Matricula> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.mt_numero_matricula NUMERO_MATRICULA, m.mt_estado_estudiante ESTADO_ESTUDIANTE, m.mt_nota_final NOTA_FINAL, m.mt_fecha_inicio FECHA_INICIO, m.mt_fecha_culminacion FECHA_CULMINACION, m.mt_estado_matricula ESTADO_MATRICULA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_MATRICULA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  m.id_estudiante = e.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " WHERE m.estado='A' ORDER BY ca.nombre, c.nombre, m.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Matricula obj = new Matricula();
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNumeroMatricula(r.getString("NUMERO_MATRICULA"));
                    obj.setEstadoEstudiante(r.getString("ESTADO_ESTUDIANTE"));
                    obj.setNotaFinal(r.getDouble("NOTA_FINAL"));
                    obj.setNombreEstudiante(r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE"));
                    obj.setIdEstudiante(r.getInt("ID_ESTUDIANTE"));
                    obj.setNombreCurso(r.getString("NOMBRE_CURSO") + " - " + r.getString("NOMBRE_CARRERA"));
                    obj.setIdCurso(r.getInt("ID_CURSO"));
                    obj.setFechaInicio(r.getDate("FECHA_INICIO"));
                    obj.setFechaCulminacion(r.getDate("FECHA_CULMINACION"));
                    obj.setEstadoMatricula(r.getString("ESTADO_MATRICULA"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Matricula getMatriculaID(String id) {
        Matricula obj = new Matricula();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();
        try {

            String sql = "SELECT m.id ID, m.nombre NOMBRE, m.descripcion DESCRIPCION, m.mt_numero_matricula NUMERO_MATRICULA, m.mt_estado_estudiante ESTADO_ESTUDIANTE, m.mt_nota_final NOTA_FINAL, m.mt_fecha_inicio FECHA_INICIO, m.mt_fecha_culminacion FECHA_CULMINACION, m.mt_estado_matricula ESTADO_MATRICULA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE, \n"
                    + " c.id ID_CURSO, c.nombre NOMBRE_CURSO, \n"
                    + " ca.id ID_CARRERA, ca.nombre NOMBRE_CARRERA \n"
                    + " FROM " + this.configGeneral.TABLA_MATRICULA + " m \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  m.id_estudiante = e.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CURSO + " c  ON  m.id_curso = c.id \n"
                    + " JOIN " + this.configGeneral.TABLA_CARRERA + " ca  ON  c.id_carrera = ca.id \n"
                    + " WHERE m.estado='A' AND m.id=" + id + " ORDER BY ca.nombre, c.nombre, m.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNumeroMatricula(r.getString("NUMERO_MATRICULA"));
                    obj.setEstadoEstudiante(r.getString("ESTADO_ESTUDIANTE"));
                    obj.setNotaFinal(r.getDouble("NOTA_FINAL"));
                    obj.setNombreEstudiante(r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE"));
                    obj.setIdEstudiante(r.getInt("ID_ESTUDIANTE"));
                    obj.setNombreCurso(r.getString("NOMBRE_CURSO") + " - " + r.getString("NOMBRE_CARRERA"));
                    obj.setIdCurso(r.getInt("ID_CURSO"));
                    obj.setFechaInicio(r.getDate("FECHA_INICIO"));
                    obj.setFechaCulminacion(r.getDate("FECHA_CULMINACION"));
                    obj.setEstadoMatricula(r.getString("ESTADO_MATRICULA"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Matricula obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();
            String sql = "INSERT INTO " + this.configGeneral.TABLA_MATRICULA + " "
                    + "(NOMBRE, DESCRIPCION, ESTADO, MT_NUMERO_MATRICULA, MT_ESTADO_ESTUDIANTE, MT_NOTA_FINAL, ID_ESTUDIANTE, ID_CURSO, MT_FECHA_INICIO, MT_FECHA_CULMINACION, MT_ESTADO_MATRICULA) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setString(3, obj.getEstado());
            preparedStatement.setString(4, obj.getNumeroMatricula());
            preparedStatement.setString(5, obj.getEstadoEstudiante());
            preparedStatement.setDouble(6, obj.getNotaFinal());
            preparedStatement.setInt(7, obj.getIdEstudiante());
            preparedStatement.setInt(8, obj.getIdCurso());
            preparedStatement.setDate(9, new java.sql.Date(obj.getFechaInicio().getTime()));
            preparedStatement.setDate(10, new java.sql.Date(obj.getFechaCulminacion().getTime()));
            preparedStatement.setString(11, obj.getEstadoMatricula());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Matricula obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_MATRICULA + " SET "
                    + "NOMBRE = ?, "
                    + "DESCRIPCION = ?, "
                    + "MT_NUMERO_MATRICULA = ?, "
                    + "MT_ESTADO_ESTUDIANTE = ?, "
                    + "MT_NOTA_FINAL = ?, "
                    + "ID_ESTUDIANTE = ?, "
                    + "ID_CURSO = ?, "
                    + "MT_FECHA_INICIO = ?, "
                    + "MT_FECHA_CULMINACION = ?, "
                    + "MT_ESTADO_MATRICULA = ? "
                    + "WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setString(3, obj.getNumeroMatricula());
            preparedStatement.setString(4, obj.getEstadoEstudiante());
            preparedStatement.setDouble(5, obj.getNotaFinal());
            preparedStatement.setInt(6, obj.getIdEstudiante());
            preparedStatement.setInt(7, obj.getIdCurso());
            preparedStatement.setDate(8, new java.sql.Date(obj.getFechaInicio().getTime()));
            preparedStatement.setDate(9, new java.sql.Date(obj.getFechaCulminacion().getTime()));
            preparedStatement.setString(10, obj.getEstadoMatricula());
            preparedStatement.setInt(11, obj.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editarNotaFinal(int id_matricula, Double notaFinal) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();
            String sql = "UPDATE  " + this.configGeneral.TABLA_MATRICULA + " SET "
                    + "MT_NOTA_FINAL = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setDouble(1, notaFinal);
            preparedStatement.setInt(2, id_matricula);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Matricula obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_MATRICULA + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
