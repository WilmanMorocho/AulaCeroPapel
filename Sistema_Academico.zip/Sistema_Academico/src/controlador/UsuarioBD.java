/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Usuario;

/**
 *
 * @author Baller
 */
public class UsuarioBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;
    DefaultTableModel tabla;

    public UsuarioBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        this.tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("APELLIDO");
            tabla.addColumn("CÉDULA");
            tabla.addColumn("TELÉFONO");
            tabla.addColumn("ROL");
            tabla.addColumn("GÉNERO");

            String sql = " SELECT u.id ID, u.nombre NOMBRE, u.APELLIDO APELLIDO, u.CEDULA CEDULA, u.TELEFONO TELEFONO, \n"
                    + " r.id ID_ROL, r.nombre NOMBRE_ROL,\n"
                    + " g.id ID_GENERO, g.nombre NOMBRE_GENERO\n"
                    + " FROM " + this.configGeneral.TABLA_USUARIO + " u \n"
                    + " JOIN " + this.configGeneral.TABLA_ROL + " r  ON  u.id_rol = r.id\n"
                    + " JOIN " + this.configGeneral.TABLA_GENERO + " g  ON  u.id_genero = g.id\n"
                    + " WHERE u.ESTADO='A' ORDER BY r.nombre";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[8];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("APELLIDO");
                    datos[4] = r.getString("CEDULA");
                    datos[5] = r.getString("TELEFONO");
                    datos[6] = r.getString("NOMBRE_ROL");
                    datos[7] = r.getString("NOMBRE_GENERO");
//                datos[3] = r.getString("ESTADO");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Usuario> getLista() throws SQLException {
        ArrayList<Usuario> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = " SELECT u.id ID, u.nombre NOMBRE, u.APELLIDO APELLIDO, u.CEDULA CEDULA, u.TELEFONO TELEFONO, \n"
                    + " r.id ID_ROL, r.nombre NOMBRE_ROL,\n"
                    + " g.id ID_GENERO, g.nombre NOMBRE_GENERO\n"
                    + " FROM " + this.configGeneral.TABLA_USUARIO + " u \n"
                    + " JOIN " + this.configGeneral.TABLA_ROL + " r  ON  u.id_rol = r.id\n"
                    + " JOIN " + this.configGeneral.TABLA_GENERO + " g  ON  u.id_genero = g.id\n"
                    + " WHERE u.ESTADO='A' ORDER BY r.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Usuario obj = new Usuario();
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setApellido(r.getString("APELLIDO"));
                    obj.setCedula(r.getString("CEDULA"));
                    obj.setTelefono(r.getString("TELEFONO"));
                    obj.setNombreRol(r.getString("NOMBRE_ROL"));
                    obj.setNombreGenero(r.getString("NOMBRE_GENERO"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Usuario getUsuarioID(String id) {
        Usuario obj = new Usuario();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();

        try {
            String sql = " SELECT u.id ID, u.nombre NOMBRE, u.APELLIDO APELLIDO, u.CEDULA CEDULA, u.TELEFONO TELEFONO, u.descripcion DESCRIPCION, u.USU_CORREO_ELECTRONICO CORREO_ELECTRONICO, u.USU_CONTRASENIA CONTRASENIA, \n"
                    + " r.id ID_ROL, r.nombre NOMBRE_ROL,\n"
                    + " g.id ID_GENERO, g.nombre NOMBRE_GENERO\n"
                    + " FROM " + this.configGeneral.TABLA_USUARIO + " u \n"
                    + " JOIN " + this.configGeneral.TABLA_ROL + " r  ON  u.id_rol = r.id\n"
                    + " JOIN " + this.configGeneral.TABLA_GENERO + " g  ON  u.id_genero = g.id\n"
                    + " WHERE u.ESTADO='A' AND u.id=" + id + "  ORDER BY r.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setApellido(r.getString("APELLIDO"));
                    obj.setCedula(r.getString("CEDULA"));
                    obj.setTelefono(r.getString("TELEFONO"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setCorreoElectronico(r.getString("CORREO_ELECTRONICO"));
                    obj.setContrasenia(r.getString("CONTRASENIA"));
                    obj.setIdRol(r.getInt("ID_ROL"));
                    obj.setNombreRol(r.getString("NOMBRE_ROL"));
                    obj.setIdGenero(r.getInt("ID_GENERO"));
                    obj.setNombreGenero(r.getString("NOMBRE_GENERO"));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public Usuario getUsuarioLogin(String email, String contrasenia) {
        Usuario obj = new Usuario();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();

        try {
            String sql = "SELECT * FROM " + this.configGeneral.TABLA_USUARIO + " "
                    + "WHERE USU_CORREO_ELECTRONICO='" + email + "' AND USU_CONTRASENIA= '" + Validaciones.Encriptar(contrasenia) + "' AND ESTADO='A'";
            
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setApellido(r.getString("APELLIDO"));
                    obj.setCedula(r.getString("CEDULA"));
                    obj.setTelefono(r.getString("TELEFONO"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setCorreoElectronico(r.getString("USU_CORREO_ELECTRONICO"));
                    obj.setContrasenia(r.getString("USU_CONTRASENIA"));
                    obj.setIdRol(r.getInt("ID_ROL"));
                    obj.setIdGenero(r.getInt("ID_GENERO"));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } catch (Exception ex) {
            Logger.getLogger(UsuarioBD.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Usuario obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "INSERT INTO " + this.configGeneral.TABLA_USUARIO + " "
                    + "(NOMBRE, APELLIDO, ESTADO, USU_CORREO_ELECTRONICO, USU_CONTRASENIA, ID_ROL, ID_GENERO, DESCRIPCION, CEDULA, TELEFONO) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getApellido());
            preparedStatement.setString(3, obj.getEstado());
            preparedStatement.setString(4, obj.getCorreoElectronico());
            preparedStatement.setString(5, obj.getContrasenia());
            preparedStatement.setInt(6, obj.getIdRol());
            preparedStatement.setInt(7, obj.getIdGenero());
            preparedStatement.setString(8, obj.getDescripcion());
            preparedStatement.setString(9, obj.getCedula());
            preparedStatement.setString(10, obj.getTelefono());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Usuario obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_USUARIO + " SET "
                    + "NOMBRE = ?, "
                    + "APELLIDO = ?, "
                    + "USU_CORREO_ELECTRONICO = ?, "
                    + "USU_CONTRASENIA = ?, "
                    + "ID_GENERO = ?, "
                    + "ID_ROL = ?, "
                    + "DESCRIPCION = ?, "
                    + "CEDULA = ?, "
                    + "TELEFONO = ? "
                    + "WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getApellido());
            preparedStatement.setString(3, obj.getCorreoElectronico());
            preparedStatement.setString(4, obj.getContrasenia());
            preparedStatement.setInt(5, obj.getIdGenero());
            preparedStatement.setInt(6, obj.getIdRol());
            preparedStatement.setString(7, obj.getDescripcion());
            preparedStatement.setString(8, obj.getCedula());
            preparedStatement.setString(9, obj.getTelefono());
            preparedStatement.setInt(10, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Usuario obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_USUARIO + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
