/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Carrera;

/**
 *
 * @author Baller
 */
public class CarreraBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public CarreraBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("FACULTAD");
            tabla.addColumn("DOCENTE ASIGNADO");
//            tabla.addColumn("ESTADO");

//            String sql = "SELECT * FROM " + this.configGeneral.TABLA_CARRERA + " WHERE estado='A' order by nombre";
            String sql = "SELECT c.id ID, c.nombre NOMBRE, c.descripcion DESCRIPCION, c.CR_FACULTAD FACULTAD,\n"
                    + " u.id ID_ASIGNADO, u.nombre NOMBRE_ASIGNADO, u.APELLIDO APELLIDO_ASIGNADO \n"
                    + " FROM " + this.configGeneral.TABLA_CARRERA + " c\n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " u  ON  c.id_asignado = u.id\n"
                    + " WHERE c.estado='A' ORDER BY u.nombre";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[5];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("FACULTAD");
                    datos[4] = r.getString("NOMBRE_ASIGNADO") + " " + r.getString("APELLIDO_ASIGNADO");
//                datos[3] = r.getString("ESTADO");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Carrera> getLista() throws SQLException {
        ArrayList<Carrera> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT c.id ID, c.nombre NOMBRE, c.descripcion DESCRIPCION, c.CR_FACULTAD FACULTAD,\n"
                    + " u.id ID_ASIGNADO, u.nombre NOMBRE_ASIGNADO, u.APELLIDO APELLIDO_ASIGNADO \n"
                    + " FROM " + this.configGeneral.TABLA_CARRERA + " c\n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " u  ON  c.id_asignado = u.id\n"
                    + " WHERE c.estado='A' ORDER BY u.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Carrera obj = new Carrera();
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setFacultad(r.getString("FACULTAD"));
                    obj.setIdAsignado(r.getInt("ID_ASIGNADO"));
                    obj.setNombreAsignado(r.getString("NOMBRE_ASIGNADO") + " " + r.getString("APELLIDO_ASIGNADO"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Carrera getCarreraID(String id) {
        Carrera obj = new Carrera();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();

        try {
//            String sql = "SELECT * FROM " + this.configGeneral.TABLA_CARRERA + " WHERE id=" + id;

            String sql = "SELECT c.id ID, c.nombre NOMBRE, c.descripcion DESCRIPCION, c.CR_FACULTAD FACULTAD,\n"
                    + " u.id ID_ASIGNADO, u.nombre NOMBRE_ASIGNADO, u.APELLIDO APELLIDO_ASIGNADO \n"
                    + " FROM " + this.configGeneral.TABLA_CARRERA + " c\n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " u  ON  c.id_asignado = u.id\n"
                    + " WHERE c.estado='A' AND c.id=" + id + " ORDER BY u.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setFacultad(r.getString("FACULTAD"));
                    obj.setIdAsignado(r.getInt("ID_ASIGNADO"));
                    obj.setNombreAsignado(r.getString("NOMBRE_ASIGNADO") + " " + r.getString("APELLIDO_ASIGNADO"));

                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Carrera obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "INSERT INTO " + this.configGeneral.TABLA_CARRERA + " "
                    + "(NOMBRE, DESCRIPCION, ESTADO, ID_ASIGNADO, CR_FACULTAD) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setString(3, obj.getEstado());
            preparedStatement.setInt(4, obj.getIdAsignado());
            preparedStatement.setString(5, obj.getFacultad());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Carrera obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_CARRERA + " SET "
                    + "NOMBRE = ?, "
                    + "DESCRIPCION = ?, "
                    + "ID_ASIGNADO = ?, "
                    + "CR_FACULTAD = ? "
                    + "WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setInt(3, obj.getIdAsignado());
            preparedStatement.setString(4, obj.getFacultad());
            preparedStatement.setInt(5, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Carrera obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_CARRERA + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
