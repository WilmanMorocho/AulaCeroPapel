/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Tarea;
import modelo.TareaEntregada;

/**
 *
 * @author Baller
 */
public class TareaBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public TareaBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("CREACIÓN");
            tabla.addColumn("ENTREGA");
            tabla.addColumn("MATÉRIA");

            String sql = "SELECT t.id ID, t.nombre NOMBRE, t.descripcion DESCRIPCION, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " m.id ID_MATERIA, m.nombre NOMBRE_MATERIA \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA + " t \n"
                    + " JOIN " + this.configGeneral.TABLA_MATERIA + " m  ON  t.id_materia = m.id \n"
                    + " WHERE t.estado='A' ORDER BY t.nombre";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = this.configGeneral.getStringDate(r.getDate("FECHA_CREACION"));
                    datos[4] = this.configGeneral.getStringDate(r.getDate("FECHA_ENTREGA"));
                    datos[5] = r.getString("NOMBRE_MATERIA");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public DefaultTableModel getTablaTareasIDMateria(String id_materia) throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("CREACIÓN");
            tabla.addColumn("ENTREGA");

            String sql = "SELECT t.id ID, t.nombre NOMBRE, t.descripcion DESCRIPCION, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " m.id ID_MATERIA, m.nombre NOMBRE_MATERIA \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA + " t \n"
                    + " JOIN " + this.configGeneral.TABLA_MATERIA + " m  ON  t.id_materia = m.id \n"
                    + " WHERE t.estado='A' AND t.id_materia=" + id_materia + " ORDER BY t.nombre";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = this.configGeneral.getStringDate(r.getDate("FECHA_CREACION"));
                    datos[4] = this.configGeneral.getStringDate(r.getDate("FECHA_ENTREGA"));
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public DefaultTableModel getTablaTareaIDMateria(String id_materia, String id_estudiante) throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("CREACIÓN");
            tabla.addColumn("ENTREGA");
            tabla.addColumn("MATÉRIA");
            tabla.addColumn("NOTA");

            String sql = "SELECT t.id ID, t.nombre NOMBRE, t.descripcion DESCRIPCION, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " m.id ID_MATERIA, m.nombre NOMBRE_MATERIA  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA + " t \n"
                    + " JOIN " + this.configGeneral.TABLA_MATERIA + " m  ON  t.id_materia = m.id \n"
                    + " WHERE t.estado='A' AND t.id_materia=" + id_materia + " ORDER BY t.ta_fecha_entrega DESC";
            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = this.configGeneral.getStringDate(r.getDate("FECHA_CREACION"));
                    datos[4] = this.configGeneral.getStringDate(r.getDate("FECHA_ENTREGA"));
                    datos[5] = r.getString("NOMBRE_MATERIA");

                    TareaEntregadaBD objDB = new TareaEntregadaBD();
                    TareaEntregada obj = new TareaEntregada();
                    obj = objDB.getTareaEntregadaIDEstudianteIdTarea(id_estudiante, r.getString("ID"));
                    datos[6] = String.valueOf(obj.getNota_entregada() != null ? obj.getNota_entregada() : "Sin calificar o entregar");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<Tarea> getLista() throws SQLException {
        ArrayList<Tarea> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT t.id ID, t.nombre NOMBRE, t.descripcion DESCRIPCION, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " m.id ID_MATERIA, m.nombre NOMBRE_MATERIA \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA + " t \n"
                    + " JOIN " + this.configGeneral.TABLA_MATERIA + " m  ON  t.id_materia = m.id \n"
                    + " WHERE t.estado='A' ORDER BY t.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    Tarea obj = new Tarea();
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setFechaCreacion(r.getDate("FECHA_CREACION"));
                    obj.setFechaEntrega(r.getDate("FECHA_ENTREGA"));
                    obj.setIdMateria(r.getInt("ID_MATERIA"));
                    obj.setNombreMateria(r.getString("NOMBRE_MATERIA"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public Double getPromedioNotaTareasIDMateriaIDEstudiante(String id_materia, String id_estudiante) throws SQLException {
        int totalTareas = 0;
        Double sumaNota = 0.0;
        Double promedio = 0.0;
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT t.id ID, t.nombre NOMBRE_TAREA, \n"
                    + " m.id ID_MATERIA, m.nombre NOMBRE_MATERIA  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA + " t \n"
                    + " JOIN " + this.configGeneral.TABLA_MATERIA + " m  ON  t.id_materia = m.id \n"
                    + " WHERE t.estado='A' AND t.id_materia=" + id_materia + " ORDER BY t.ta_fecha_entrega DESC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    totalTareas++;
                    TareaEntregadaBD objDB = new TareaEntregadaBD();
                    TareaEntregada obj = new TareaEntregada();
                    obj = objDB.getTareaEntregadaIDEstudianteIdTarea(id_estudiante, r.getString("ID"));
                    sumaNota += obj.getNota_entregada();
                }
            }
            promedio = sumaNota / totalTareas;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            promedio = 0.0;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            promedio = 0.0;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return Math.round(promedio * 100.0) / 100.0;
    }

    public Tarea getTareaID(String id) {
        Tarea obj = new Tarea();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();
        try {

            String sql = "SELECT t.id ID, t.nombre NOMBRE, t.descripcion DESCRIPCION, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " m.id ID_MATERIA, m.nombre NOMBRE_MATERIA \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA + " t \n"
                    + " JOIN " + this.configGeneral.TABLA_MATERIA + " m  ON  t.id_materia = m.id \n"
                    + " WHERE t.estado='A' AND t.id=" + id + " ORDER BY t.nombre";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setNombre(r.getString("NOMBRE"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setFechaCreacion(r.getDate("FECHA_CREACION"));
                    obj.setFechaEntrega(r.getDate("FECHA_ENTREGA"));
                    obj.setIdMateria(r.getInt("ID_MATERIA"));
                    obj.setNombreMateria(r.getString("NOMBRE_MATERIA"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(Tarea obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();
            String sql = "INSERT INTO " + this.configGeneral.TABLA_TAREA + " "
                    + "(NOMBRE, TA_FECHA_CREACION, TA_FECHA_ENTREGA, DESCRIPCION, ESTADO, ID_MATERIA) VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setDate(2, new java.sql.Date(obj.getFechaCreacion().getTime()));
            preparedStatement.setDate(3, new java.sql.Date(obj.getFechaEntrega().getTime()));
            preparedStatement.setString(4, obj.getDescripcion());
            preparedStatement.setString(5, obj.getEstado());
            preparedStatement.setInt(6, obj.getIdMateria());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(Tarea obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_TAREA + " SET "
                    + "NOMBRE = ?, "
                    + "DESCRIPCION = ?, "
                    + "TA_FECHA_CREACION = ?, "
                    + "TA_FECHA_ENTREGA = ?, "
                    + "ID_MATERIA = ? "
                    + "WHERE ID = ?";

            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getNombre());
            preparedStatement.setString(2, obj.getDescripcion());
            preparedStatement.setDate(3, new java.sql.Date(obj.getFechaCreacion().getTime()));
            preparedStatement.setDate(4, new java.sql.Date(obj.getFechaEntrega().getTime()));
            preparedStatement.setInt(5, obj.getIdMateria());
            preparedStatement.setInt(6, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(Tarea obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_TAREA + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
