/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import configuraciones.ConexionOracle;
import configuraciones.Validaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.TareaEntregada;

/**
 *
 * @author Baller
 */
public class TareaEntregadaBD {

    Validaciones configGeneral;
    ConexionOracle conexionOracle;

    public TareaEntregadaBD() {
        this.configGeneral = new Validaciones();
    }

    public DefaultTableModel getTabla() throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();

        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("NOTA");
            tabla.addColumn("CREACIÓN");
            tabla.addColumn("ENTREGA");
            tabla.addColumn("ESTUDIANTE");

            String sql = "SELECT te.id ID, te.descripcion DESARROLLO, te.te_nota NOTA, \n"
                    + " t.id ID_TAREA, t.nombre NOMBRE_MATERIA, t.descripcion INDICACIONES, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " e.id ID_ESTUDIANTE, t.nombre NOMBRE_ESTUDIANTE, t.apellido APELLIDO_ESTUDIANTE  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA_ENTREGADA + " te \n"
                    + " JOIN " + this.configGeneral.TABLA_TAREA + " t  ON  te.id_tarea = t.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  te.id_estudiante = e.id \n"
                    + " WHERE te.estado='A' ORDER BY t.ta_fecha_entrega, t.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOTA");
                    datos[4] = this.configGeneral.getStringDate(r.getDate("FECHA_CREACION"));
                    datos[5] = this.configGeneral.getStringDate(r.getDate("FECHA_ENTREGA"));
                    datos[6] = r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public DefaultTableModel getTablaTareaEntregaIDTarea(String id_tarea) throws SQLException {
        DefaultTableModel tabla = new DefaultTableModel();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {
            //Creamos la cabecera de la tabla
            tabla.addColumn("ID");
            tabla.addColumn("N°");
            tabla.addColumn("NOMBRE");
            tabla.addColumn("NOTA");
            tabla.addColumn("CREACIÓN");
            tabla.addColumn("ENTREGA");
            tabla.addColumn("ESTUDIANTE");

            String sql = "SELECT te.id ID, te.descripcion DESARROLLO, te.te_nota NOTA, \n"
                    + " t.id ID_TAREA, t.nombre NOMBRE, t.descripcion INDICACIONES, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA_ENTREGADA + " te \n"
                    + " JOIN " + this.configGeneral.TABLA_TAREA + " t  ON  te.id_tarea = t.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  te.id_estudiante = e.id \n"
                    + " WHERE te.estado='A' AND t.id=" + id_tarea + " ORDER BY t.ta_fecha_entrega, t.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();

                String datos[] = new String[7];//número de columnas
                int fila = 0;
                while (r.next()) {
                    fila++;
                    datos[0] = r.getString("ID");
                    datos[1] = String.valueOf(fila);
                    datos[2] = r.getString("NOMBRE");
                    datos[3] = r.getString("NOTA");
                    datos[4] = this.configGeneral.getStringDate(r.getDate("FECHA_CREACION"));
                    datos[5] = this.configGeneral.getStringDate(r.getDate("FECHA_ENTREGA"));
                    datos[6] = r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE");
                    tabla.addRow(datos);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            tabla = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return tabla;
    }

    public ArrayList<TareaEntregada> getLista() throws SQLException {
        ArrayList<TareaEntregada> lista = new ArrayList<>();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        Connection conexion = this.conexionOracle.conectar();
        try ( Statement sentencia = this.conexionOracle.getSentencia()) {

            String sql = "SELECT te.id ID, te.descripcion DESARROLLO, te.te_nota NOTA, \n"
                    + " t.id ID_TAREA, t.nombre NOMBRE, t.descripcion INDICACIONES, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " e.id ID_ESTUDIANTE, t.nombre NOMBRE_ESTUDIANTE, t.apellido APELLIDO_ESTUDIANTE  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA_ENTREGADA + " te \n"
                    + " JOIN " + this.configGeneral.TABLA_TAREA + " t  ON  te.id_tarea = t.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  te.id_estudiante = e.id \n"
                    + " WHERE te.estado='A' ORDER BY t.ta_fecha_entrega, t.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    TareaEntregada obj = new TareaEntregada();
                    obj.setId(r.getInt("ID"));
                    obj.setDescripcion(r.getString("DESCRIPCION"));
                    obj.setNota_entregada(r.getDouble("NOTA"));

                    obj.setIdTarea(r.getInt("ID_TAREA"));
                    obj.setNombreTarea(r.getString("NOMBRE"));

                    obj.setIdEstudiante(r.getInt("ID_ESTUDIANTE"));
                    obj.setNombreEstudiante(r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE"));
                    lista.add(obj);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
            lista = null;
            throw e;
        } finally {
            conexion.close();
            this.conexionOracle.desconectar();
        }
        return lista;
    }

    public TareaEntregada getTareaEntregadaID(String id) {
        TareaEntregada obj = new TareaEntregada();
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();
        try {

            String sql = "SELECT te.id ID, te.descripcion DESARROLLO, te.te_nota NOTA, \n"
                    + " t.id ID_TAREA, t.nombre NOMBRE_TAREA, t.descripcion INDICACIONES, t.ta_fecha_creacion FECHA_CREACION, t.ta_fecha_entrega FECHA_ENTREGA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA_ENTREGADA + " te \n"
                    + " JOIN " + this.configGeneral.TABLA_TAREA + " t  ON  te.id_tarea = t.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  te.id_estudiante = e.id \n"
                    + " WHERE te.estado='A' AND te.id=" + id + " ORDER BY t.ta_fecha_entrega, t.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setDescripcion(r.getString("DESARROLLO"));
                    obj.setNota_entregada(r.getDouble("NOTA"));

                    obj.setIdTarea(r.getInt("ID_TAREA"));
                    obj.setNombreTarea(r.getString("NOMBRE_TAREA"));

                    obj.setIdEstudiante(r.getInt("ID_ESTUDIANTE"));
                    obj.setNombreEstudiante(r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public TareaEntregada getTareaEntregadaIDEstudianteIdTarea(String id_estudiante, String id_tarea) {
        TareaEntregada obj = new TareaEntregada();
        obj.setNota_entregada(0.0);
        //Realizamos la conexión con la base de datos
        this.conexionOracle = new ConexionOracle();
        this.conexionOracle.conectar();
        Statement sentencia = this.conexionOracle.getSentencia();
        try {

            String sql = "SELECT te.id ID, te.descripcion DESARROLLO, te.te_nota NOTA, \n"
                    + " t.id ID_TAREA, t.nombre NOMBRE_TAREA, \n"
                    + " e.id ID_ESTUDIANTE, e.nombre NOMBRE_ESTUDIANTE, e.apellido APELLIDO_ESTUDIANTE  \n"
                    + " FROM " + this.configGeneral.TABLA_TAREA_ENTREGADA + " te \n"
                    + " JOIN " + this.configGeneral.TABLA_TAREA + " t  ON  te.id_tarea = t.id \n"
                    + " JOIN " + this.configGeneral.TABLA_USUARIO + " e  ON  te.id_estudiante = e.id \n"
                    + " WHERE te.estado='A' AND e.id=" + id_estudiante + " AND t.id=" + id_tarea + " ORDER BY t.nombre ASC";

            try ( ResultSet r = sentencia.executeQuery(sql)) {
                r.beforeFirst();
                while (r.next()) {
                    obj.setId(r.getInt("ID"));
                    obj.setDescripcion(r.getString("DESARROLLO"));
                    obj.setNota_entregada(r.getDouble("NOTA"));
                    obj.setIdTarea(r.getInt("ID_TAREA"));
                    obj.setNombreTarea(r.getString("NOMBRE_TAREA"));
                    obj.setIdEstudiante(r.getInt("ID_ESTUDIANTE"));
                    obj.setNombreEstudiante(r.getString("NOMBRE_ESTUDIANTE") + " " + r.getString("APELLIDO_ESTUDIANTE"));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.cargaDatosError + e.getMessage());
        } finally {
            this.conexionOracle.desconectar();
        }
        return obj;
    }

    public void guardar(TareaEntregada obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();
            String sql = "INSERT INTO " + this.configGeneral.TABLA_TAREA_ENTREGADA + " "
                    + "(DESCRIPCION, ESTADO, TE_NOTA, ID_ESTUDIANTE, ID_TAREA) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getDescripcion());
            preparedStatement.setString(2, obj.getEstado());
            preparedStatement.setDouble(3, obj.getNota_entregada());
            preparedStatement.setInt(4, obj.getIdEstudiante());
            preparedStatement.setInt(5, obj.getIdTarea());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.guardadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void editar(TareaEntregada obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_TAREA_ENTREGADA + " SET "
                    + "DESCRIPCION = ?, "
                    + "TE_NOTA = ?, "
                    + "ID_ESTUDIANTE = ?, "
                    + "ID_TAREA = ? "
                    + "WHERE ID = ?";

            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getDescripcion());
            preparedStatement.setDouble(2, obj.getNota_entregada());
            preparedStatement.setInt(3, obj.getIdEstudiante());
            preparedStatement.setInt(4, obj.getIdTarea());
            preparedStatement.setInt(5, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.editadoCorrecto);
            this.conexionOracle.desconectar();
        }
    }

    public void eliminar(TareaEntregada obj) {
        try {
            this.conexionOracle = new ConexionOracle();
            Connection conexion = this.conexionOracle.conectar();

            String sql = "UPDATE  " + this.configGeneral.TABLA_TAREA_ENTREGADA + " SET "
                    + "ESTADO = ? WHERE ID = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setString(1, obj.getEstado());
            preparedStatement.setInt(2, obj.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoError + e.getMessage());
        } finally {
            JOptionPane.showMessageDialog(null, this.configGeneral.eliminoCorrecto);
            this.conexionOracle.desconectar();
        }
    }
}
